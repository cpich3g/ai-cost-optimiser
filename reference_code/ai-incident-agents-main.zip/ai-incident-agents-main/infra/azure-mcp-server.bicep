// ============================================================================
// Azure MCP Server -- Container App with Managed Identity
//
// Deploys the official Azure MCP Server (mcr.microsoft.com/azure-sdk/azure-mcp)
// on Azure Container Apps with a system-assigned Managed Identity that has
// Reader + Monitoring Reader + Log Analytics Reader on the target resource group.
//
// Usage:
//   az deployment group create \
//     -g rg-durable-agents-hitl \
//     -f infra/azure-mcp-server.bicep \
//     -p targetResourceGroupName=rg-durable-agents-hitl
// ============================================================================

@description('Name of the Container App')
param containerAppName string = 'ca-azure-mcp-server'

@description('Name of the Container Apps Environment')
param environmentName string = 'cae-azure-mcp'

@description('Location for all resources')
param location string = resourceGroup().location

@description('Container image')
param containerImage string = 'mcr.microsoft.com/azure-sdk/azure-mcp:latest'

// ============================================================================
// Log Analytics Workspace (required by Container Apps Environment)
// ============================================================================
resource logAnalytics 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: 'law-azure-mcp'
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
}

// ============================================================================
// Container Apps Environment
// ============================================================================
resource environment 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: environmentName
  location: location
  properties: {
    appLogsConfiguration: {
      destination: 'log-analytics'
      logAnalyticsConfiguration: {
        customerId: logAnalytics.properties.customerId
        sharedKey: logAnalytics.listKeys().primarySharedKey
      }
    }
  }
}

// ============================================================================
// Container App -- Azure MCP Server
// ============================================================================
resource containerApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: containerAppName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    managedEnvironmentId: environment.id
    configuration: {
      ingress: {
        external: true
        targetPort: 8080
        transport: 'http'
        allowInsecure: false
      }
    }
    template: {
      containers: [
        {
          name: 'azure-mcp-server'
          image: containerImage
          resources: {
            cpu: json('0.5')
            memory: '1Gi'
          }
          env: [
            {
              name: 'AZURE_MCP_TRANSPORT'
              value: 'streamable-http'
            }
            {
              name: 'AZURE_MCP_PORT'
              value: '8080'
            }
          ]
        }
      ]
      scale: {
        minReplicas: 0
        maxReplicas: 2
        rules: [
          {
            name: 'http-scaler'
            http: {
              metadata: {
                concurrentRequests: '10'
              }
            }
          }
        ]
      }
    }
  }
}

// ============================================================================
// Role Assignments -- grant the Container App MI access to the target RG
// ============================================================================

// Reader (acdd72a7-3385-48ef-bd42-f606fba81ae7)
var readerRoleId = 'acdd72a7-3385-48ef-bd42-f606fba81ae7'

// Monitoring Reader (43d0d8ad-25c7-4714-9337-8ba259a9fe05)
var monitoringReaderRoleId = '43d0d8ad-25c7-4714-9337-8ba259a9fe05'

// Log Analytics Reader (73c42c96-874c-492b-b04d-ab87d138a893)
var logAnalyticsReaderRoleId = '73c42c96-874c-492b-b04d-ab87d138a893'

resource readerRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(resourceGroup().id, containerApp.id, readerRoleId)
  scope: resourceGroup()
  properties: {
    principalId: containerApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', readerRoleId)
  }
}

resource monitoringReaderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(resourceGroup().id, containerApp.id, monitoringReaderRoleId)
  scope: resourceGroup()
  properties: {
    principalId: containerApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', monitoringReaderRoleId)
  }
}

resource logAnalyticsReaderRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(resourceGroup().id, containerApp.id, logAnalyticsReaderRoleId)
  scope: resourceGroup()
  properties: {
    principalId: containerApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', logAnalyticsReaderRoleId)
  }
}

// ============================================================================
// Outputs
// ============================================================================
output containerAppUrl string = 'https://${containerApp.properties.configuration.ingress.fqdn}'
output containerAppName string = containerApp.name
output principalId string = containerApp.identity.principalId
