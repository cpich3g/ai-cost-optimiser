// ============================================================================
// AI Incident Responder - Infrastructure
// Deploys: VNet, Storage (MI + Private Endpoints), App Service Plan,
//          Function App (MI + VNet integration), Storage RBAC
// Durable Task Scheduler + Task Hub deployed via deploy.ps1 (REST API)
// Does NOT deploy: SignalR, Azure OpenAI / Foundry (already exist)
// Foundry + Scheduler RBAC assigned via deploy.ps1 (cross-resource-group)
// ============================================================================

targetScope = 'resourceGroup'

@description('Base name used to derive resource names')
param baseName string = 'durableagentshitl'

@description('Location for all resources')
param location string = resourceGroup().location

@description('Azure SignalR connection string')
@secure()
param signalRConnectionString string

@description('Azure OpenAI endpoint URL')
param azureOpenAiEndpoint string

@description('Deployment name for Azure OpenAI chat model')
param azureOpenAiDeploymentName string = 'gpt-4.1'

@description('Durable Task Scheduler connection string (pre-created)')
@secure()
param durableTaskConnectionString string

// ---- Derived names ----
var uniqueSuffix = uniqueString(resourceGroup().id, baseName)
var storageAccountName = 'st${take(replace(baseName, '-', ''), 14)}${take(uniqueSuffix, 6)}'
var functionAppName = 'func-${baseName}'
var appServicePlanName = 'asp-${baseName}'
var vnetName = 'vnet-${baseName}'

// ---- Storage private-endpoint configs (loop-friendly) ----
var storagePeConfigs = [
  { suffix: 'blob',  group: 'blob',  zone: 'privatelink.blob.${environment().suffixes.storage}' }
  { suffix: 'queue', group: 'queue', zone: 'privatelink.queue.${environment().suffixes.storage}' }
  { suffix: 'table', group: 'table', zone: 'privatelink.table.${environment().suffixes.storage}' }
  { suffix: 'file',  group: 'file',  zone: 'privatelink.file.${environment().suffixes.storage}' }
]

// ---- Built-in RBAC role-definition IDs ----
var storageBlobDataOwnerRoleId        = 'b7e6dc6d-f1e8-4753-8033-0f276bb0955b'
var storageQueueDataContributorRoleId = '974c5e8b-45b9-4653-ba55-5f855dd0fb88'
var storageTableDataContributorRoleId = '0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3'
var storageAccountContributorRoleId   = '17d1049b-9a84-46fb-8f53-869881c3d3ab'

// ============================================================================
// Virtual Network
// ============================================================================
resource vnet 'Microsoft.Network/virtualNetworks@2023-11-01' = {
  name: vnetName
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [ '10.0.0.0/16' ]
    }
  }
}

// Function-app integration subnet (delegated to Microsoft.Web/serverFarms)
resource snetFunc 'Microsoft.Network/virtualNetworks/subnets@2023-11-01' = {
  parent: vnet
  name: 'snet-func'
  properties: {
    addressPrefix: '10.0.1.0/24'
    delegations: [
      {
        name: 'delegation-web'
        properties: {
          serviceName: 'Microsoft.Web/serverFarms'
        }
      }
    ]
  }
}

// Private-endpoint subnet
resource snetPe 'Microsoft.Network/virtualNetworks/subnets@2023-11-01' = {
  parent: vnet
  name: 'snet-pe'
  properties: {
    addressPrefix: '10.0.2.0/24'
  }
  dependsOn: [ snetFunc ] // serialize subnet puts to avoid ARM conflicts
}

// ============================================================================
// Storage Account (identity-based auth, no shared key, firewall deny)
// ============================================================================
resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageAccountName
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
  properties: {
    supportsHttpsTrafficOnly: true
    minimumTlsVersion: 'TLS1_2'
    allowBlobPublicAccess: false
    allowSharedKeyAccess: false
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'AzureServices'
    }
  }
}

// ============================================================================
// Private DNS Zones + VNet Links
// ============================================================================
resource privateDnsZones 'Microsoft.Network/privateDnsZones@2020-06-01' = [for cfg in storagePeConfigs: {
  name: cfg.zone
  location: 'global'
}]

resource dnsZoneVnetLinks 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = [for (cfg, i) in storagePeConfigs: {
  parent: privateDnsZones[i]
  name: '${vnetName}-link'
  location: 'global'
  properties: {
    virtualNetwork: { id: vnet.id }
    registrationEnabled: false
  }
}]

// ============================================================================
// Storage Private Endpoints + DNS Zone Groups
// ============================================================================
resource storagePrivateEndpoints 'Microsoft.Network/privateEndpoints@2023-11-01' = [for (cfg, i) in storagePeConfigs: {
  name: 'pe-${storageAccountName}-${cfg.suffix}'
  location: location
  properties: {
    subnet: { id: snetPe.id }
    privateLinkServiceConnections: [
      {
        name: 'pls-${cfg.suffix}'
        properties: {
          privateLinkServiceId: storageAccount.id
          groupIds: [ cfg.group ]
        }
      }
    ]
  }
}]

resource peZoneGroups 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = [for (cfg, i) in storagePeConfigs: {
  parent: storagePrivateEndpoints[i]
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: cfg.suffix
        properties: {
          privateDnsZoneId: privateDnsZones[i].id
        }
      }
    ]
  }
}]

// ============================================================================
// App Service Plan (Linux B1)
// ============================================================================
resource appServicePlan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: appServicePlanName
  location: location
  kind: 'linux'
  sku: { name: 'B1', tier: 'Basic' }
  properties: { reserved: true }
}

// ============================================================================
// Function App – System MI, VNet integrated, identity-based storage
// ============================================================================
resource functionApp 'Microsoft.Web/sites@2023-12-01' = {
  name: functionAppName
  location: location
  kind: 'functionapp,linux'
  identity: { type: 'SystemAssigned' }
  properties: {
    serverFarmId: appServicePlan.id
    httpsOnly: true
    virtualNetworkSubnetId: snetFunc.id
    vnetRouteAllEnabled: true
    siteConfig: {
      linuxFxVersion: 'PYTHON|3.12'
      pythonVersion: '3.12'
      cors: { allowedOrigins: [ '*' ] }
      appSettings: [
        { name: 'FUNCTIONS_WORKER_RUNTIME',                value: 'python' }
        { name: 'FUNCTIONS_EXTENSION_VERSION',             value: '~4' }
        { name: 'AzureWebJobsStorage__accountName',        value: storageAccount.name }
        { name: 'AzureWebJobsFeatureFlags',                value: 'EnableWorkerIndexing' }
        { name: 'WEBSITE_RUN_FROM_PACKAGE',                value: '1' }
        { name: 'AzureSignalRConnectionString',            value: signalRConnectionString }
        { name: 'AZURE_OPENAI_ENDPOINT',                   value: azureOpenAiEndpoint }
        { name: 'AZURE_OPENAI_CHAT_DEPLOYMENT_NAME',       value: azureOpenAiDeploymentName }
        { name: 'DURABLE_TASK_SCHEDULER_CONNECTION_STRING', value: durableTaskConnectionString }
        { name: 'TASKHUB_NAME',                            value: 'default' }
        { name: 'APPROVAL_TIMEOUT_HOURS',                  value: '72' }
        { name: 'SCM_DO_BUILD_DURING_DEPLOYMENT',          value: 'true' }
      ]
    }
  }
  dependsOn: [ peZoneGroups, dnsZoneVnetLinks ] // ensure DNS is ready before app starts
}

// ============================================================================
// Storage RBAC for Function App Managed Identity
// ============================================================================
resource blobDataOwnerRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storageAccount.id, functionApp.id, storageBlobDataOwnerRoleId)
  scope: storageAccount
  properties: {
    principalId: functionApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageBlobDataOwnerRoleId)
  }
}

resource queueDataContributorRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storageAccount.id, functionApp.id, storageQueueDataContributorRoleId)
  scope: storageAccount
  properties: {
    principalId: functionApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageQueueDataContributorRoleId)
  }
}

resource tableDataContributorRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storageAccount.id, functionApp.id, storageTableDataContributorRoleId)
  scope: storageAccount
  properties: {
    principalId: functionApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageTableDataContributorRoleId)
  }
}

resource storageAccountContributorRole 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(storageAccount.id, functionApp.id, storageAccountContributorRoleId)
  scope: storageAccount
  properties: {
    principalId: functionApp.identity.principalId
    principalType: 'ServicePrincipal'
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', storageAccountContributorRoleId)
  }
}

// ============================================================================
// Outputs
// ============================================================================
output functionAppName string = functionApp.name
output functionAppHostName string = functionApp.properties.defaultHostName
output principalId string = functionApp.identity.principalId
output storageAccountName string = storageAccount.name
output vnetName string = vnet.name
