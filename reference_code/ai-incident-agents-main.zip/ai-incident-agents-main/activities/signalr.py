"""SignalR notification activity.

Sends real-time events to the frontend via Azure SignalR Service.
Reused from the bpmnv3 project pattern.
"""

import json
import logging


def register_signalr_activities(app, hub_name: str, connection_setting: str):
    """Register SignalR-related activities with the app."""

    @app.activity_trigger(input_name="payload")
    @app.generic_output_binding(
        arg_name="signalRMessages",
        type="signalR",
        hub_name=hub_name,
        connection_string_setting=connection_setting,
    )
    def notify_user(payload: dict, signalRMessages) -> dict:
        """Send a SignalR notification to a specific user.

        Payload:
        {
            "user_id": str,       # Target user
            "instance_id": str,   # Orchestration instance
            "event": str,         # Event type (e.g. "analysis_started")
            "data": dict          # Event-specific data
        }
        """
        user_id = payload.get("user_id")
        instance_id = payload.get("instance_id")
        event = payload.get("event")
        data = payload.get("data", {})

        if not user_id:
            logging.warning("No user_id provided for notification: %s", event)
            return {"sent": False, "reason": "no_user_id"}

        message = {
            "userId": user_id,
            "target": event,
            "arguments": [{"instance_id": instance_id, **data}],
        }

        signalRMessages.set(json.dumps([message]))
        logging.info("SignalR: %s -> user %s (instance: %s)", event, user_id, instance_id)

        return {"sent": True, "event": event, "user_id": user_id}

    return notify_user
