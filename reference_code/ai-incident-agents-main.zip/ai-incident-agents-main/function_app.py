"""AI Incident Responder - Azure Durable Functions with Microsoft Agent Framework.

Entry point for the Azure Functions app. Registers:
  - Two AI agents via Agent Framework (IncidentAnalyzer, RemediationExecutor)
  - Durable orchestration for incident response with HITL approval
  - SignalR activities for real-time frontend streaming
  - HTTP endpoints for incident management and the UI
  - MCP (Model Context Protocol) tools for live Azure diagnostics + docs search
"""

import json
import logging
import os
from pathlib import Path

import azure.functions as func

from agent_framework.azure import AgentFunctionApp, AzureOpenAIChatClient
from agent_framework import tool

from config import (
    SIGNALR_HUB_NAME,
    SIGNALR_CONNECTION_SETTING,
    LEARN_MCP_URL,
    AZURE_MCP_SERVER_URL,
    AZURE_MCP_APP_ID,
    ENABLE_MCP_TOOLS,
)
from activities.signalr import register_signalr_activities
from orchestrators.incident_response import register_orchestrator


# =============================================================================
# Agent Setup -- Microsoft Agent Framework
# =============================================================================

# Authentication priority:
#   1. API key (AZURE_OPENAI_API_KEY) -- simplest for local dev
#   2. DefaultAzureCredential -- works with Azure CLI, Managed Identity, etc.
#
# If no API key is set, we fall back to DefaultAzureCredential which tries
# (in order): environment creds, workload identity, managed identity,
# Azure CLI, Azure PowerShell, Azure Developer CLI, and more.
# See: https://learn.microsoft.com/python/api/azure-identity/azure.identity.defaultazurecredential

api_key = os.getenv("AZURE_OPENAI_API_KEY")

if api_key:
    logging.info("Using API key authentication for Azure OpenAI")
    chat_client = AzureOpenAIChatClient(api_key=api_key)
else:
    from azure.identity import DefaultAzureCredential

    logging.info("No API key found; using DefaultAzureCredential for Azure OpenAI")
    chat_client = AzureOpenAIChatClient(
        credential=DefaultAzureCredential(),
    )

# =============================================================================
# MCP Tools -- Direct HTTP wrappers (bypass streaming transport)
# =============================================================================
# The MCPStreamableHTTPTool transport (anyio TaskGroups + SSE) hangs inside
# Azure Durable Functions entities.  Instead, we call MCP servers via plain
# HTTP POST (JSON-RPC), which works reliably in any execution context.

import httpx as _httpx
from mcp_tools import (
    get_learn_client,
    get_azure_client,
    microsoft_docs_search,
    microsoft_code_sample_search,
    microsoft_docs_fetch,
    azure_monitor_query,
    azure_resource_health,
    azure_advisor_recommendations,
    azure_appinsights_query,
    azure_applens_diagnose,
    azure_storage_operations,
    azure_compute_operations,
    azure_appservice_operations,
)

analyzer_tools: list = []
_mcp_timeout = _httpx.Timeout(connect=30.0, read=60.0, write=30.0, pool=30.0)

if ENABLE_MCP_TOOLS:
    # ---- Microsoft Learn MCP -- public, no auth ----
    try:
        _learn_http = _httpx.AsyncClient(timeout=_mcp_timeout)
        get_learn_client(LEARN_MCP_URL, _learn_http)
        # Register the three Learn MCP tools as plain function tools
        analyzer_tools.extend([
            tool(microsoft_docs_search),
            tool(microsoft_code_sample_search),
            tool(microsoft_docs_fetch),
        ])
        logging.info("Learn MCP direct tools registered for: %s", LEARN_MCP_URL)
    except Exception as exc:
        logging.warning("Learn MCP tool setup failed: %s", exc)

    # ---- Azure MCP Server -- hosted on Container App with Managed Identity ----
    if AZURE_MCP_SERVER_URL:
        try:
            if AZURE_MCP_APP_ID:
                from azure.identity.aio import (
                    DefaultAzureCredential as AsyncDefaultAzureCredential,
                )

                _mcp_credential = AsyncDefaultAzureCredential()
                _mcp_scope = f"api://{AZURE_MCP_APP_ID}/.default"

                class _AzureMcpAuth(_httpx.Auth):
                    """Injects an Entra ID Bearer token into every outbound MCP request."""

                    requires_response_body = False

                    async def async_auth_flow(self, request):
                        token = await _mcp_credential.get_token(_mcp_scope)
                        request.headers["Authorization"] = f"Bearer {token.token}"
                        yield request

                _azure_http = _httpx.AsyncClient(auth=_AzureMcpAuth(), timeout=_mcp_timeout)
            else:
                _azure_http = _httpx.AsyncClient(timeout=_mcp_timeout)

            _azure_mcp = get_azure_client(AZURE_MCP_SERVER_URL, _azure_http)
            logging.info("Azure MCP direct client registered for: %s", AZURE_MCP_SERVER_URL)
            # Register curated Azure MCP tools for incident diagnostics
            analyzer_tools.extend([
                tool(azure_monitor_query),
                tool(azure_resource_health),
                tool(azure_advisor_recommendations),
                tool(azure_appinsights_query),
                tool(azure_applens_diagnose),
                tool(azure_storage_operations),
                tool(azure_compute_operations),
                tool(azure_appservice_operations),
            ])
            logging.info("Azure MCP tools registered: monitor, resourcehealth, advisor, appinsights, applens, storage, compute, appservice")
        except Exception as exc:
            logging.warning("Azure MCP tool setup failed: %s", exc)
else:
    logging.info("MCP tools disabled via ENABLE_MCP_TOOLS=false")

logging.info("Analyzer tools: %s", [getattr(t, 'name', str(t)) for t in analyzer_tools])

# =============================================================================
# AI Agents
# =============================================================================

_analyzer_instructions_base = (
    "You are an expert production incident response analyst.\n\n"
    "You always respond with well-structured JSON as requested. "
    "You are thorough, precise, and include confidence levels in your assessments. "
    "Your remediation steps are ordered by priority and include risk assessments."
)

_has_learn_tools = any(
    getattr(t, "name", "") in ("microsoft_docs_search", "microsoft_code_sample_search", "microsoft_docs_fetch")
    for t in analyzer_tools
)

_has_azure_tools = any(
    getattr(t, "name", "") in ("azure_monitor_query", "azure_resource_health", "azure_advisor_recommendations")
    for t in analyzer_tools
)

if analyzer_tools:
    _tool_desc_parts = []
    if _has_learn_tools:
        _tool_desc_parts.append(
            "DOCUMENTATION TOOLS (Microsoft Learn MCP):\n"
            "- microsoft_docs_search: search Microsoft Learn docs for troubleshooting guides\n"
            "- microsoft_code_sample_search: search code samples\n"
            "- microsoft_docs_fetch: fetch a specific doc page for full content\n"
        )
    if _has_azure_tools:
        _tool_desc_parts.append(
            "AZURE DIAGNOSTICS TOOLS (Azure MCP - LIVE data):\n"
            "- azure_monitor_query: query Azure Monitor metrics and logs (KQL queries, resource metrics)\n"
            "- azure_resource_health: check resource availability/health status and platform events\n"
            "- azure_advisor_recommendations: get Azure Advisor recommendations (HighAvailability, Performance, etc)\n"
            "- azure_appinsights_query: query Application Insights components\n"
            "- azure_applens_diagnose: run AI-powered diagnostics on an Azure resource\n"
            "- azure_storage_operations: list/inspect storage accounts, containers, blobs\n"
            "- azure_compute_operations: list/inspect VMs, get instance views, check status\n"
            "- azure_appservice_operations: list/inspect web apps, get metrics, restart\n"
        )
    _analyzer_instructions = (
        _analyzer_instructions_base + "\n\n"
        "TOOLS AVAILABLE:\n"
        + "\n".join(_tool_desc_parts)
        + "\nWORKFLOW:\n"
        "1. When given an incident report, use Azure diagnostics tools to gather LIVE data "
        "(metrics, health, advisor recommendations) when resource details are provided\n"
        "2. Use documentation tools to find relevant troubleshooting guides\n"
        "3. Correlate live findings with documentation to produce a thorough diagnosis\n"
        "4. Propose concrete, prioritized remediation steps backed by evidence"
    )
else:
    _analyzer_instructions = (
        _analyzer_instructions_base + "\n\n"
        "Based on your deep expertise in cloud infrastructure, Azure services, "
        "and production incident management, analyze the incident thoroughly "
        "and provide your professional assessment. Even without live diagnostic "
        "tools, provide a detailed likely-cause analysis, confidence level, and "
        "concrete remediation steps based on the symptoms described."
    )

analyzer_agent = chat_client.as_agent(
    name="IncidentAnalyzer",
    instructions=_analyzer_instructions,
    tools=analyzer_tools if analyzer_tools else None,
)

remediator_agent = chat_client.as_agent(
    name="RemediationExecutor",
    instructions=(
        "You are a remediation execution specialist for production systems. "
        "When given a remediation step, you describe how you would execute it, "
        "including the specific commands, API calls, or configuration changes needed. "
        "You simulate the execution and report the outcome realistically. "
        "You always respond with well-structured JSON as requested. "
        "You are careful about risk assessment and rollback procedures."
    ),
)

# =============================================================================
# App Setup -- AgentFunctionApp (extends df.DFApp)
# =============================================================================

app = AgentFunctionApp(
    agents=[analyzer_agent, remediator_agent],
    enable_health_check=True,
)

# Register orchestration + activities
register_orchestrator(app)
register_signalr_activities(app, SIGNALR_HUB_NAME, SIGNALR_CONNECTION_SETTING)


# =============================================================================
# UI - Serve index.html
# =============================================================================


@app.route(route="index", methods=["GET"])
async def http_index(req: func.HttpRequest) -> func.HttpResponse:
    """Serve the main UI page."""
    html_path = Path(__file__).parent / "content" / "index.html"
    try:
        with open(html_path) as f:
            return func.HttpResponse(f.read(), mimetype="text/html")
    except FileNotFoundError:
        return func.HttpResponse(
            body="<h1>AI Incident Responder</h1><p>UI not found.</p>",
            status_code=200,
            mimetype="text/html",
        )


# =============================================================================
# SignalR - Negotiate Endpoint
# =============================================================================


@app.route(route="negotiate", methods=["POST", "GET"])
@app.generic_input_binding(
    arg_name="connectionInfo",
    type="signalRConnectionInfo",
    hub_name=SIGNALR_HUB_NAME,
    connection_string_setting=SIGNALR_CONNECTION_SETTING,
    user_id="{headers.x-user-id}",
)
async def negotiate(
    req: func.HttpRequest,
    connectionInfo: str,
) -> func.HttpResponse:
    """Returns SignalR connection URL and access token for clients."""
    return func.HttpResponse(
        body=connectionInfo,
        status_code=200,
        mimetype="application/json",
    )


# =============================================================================
# Incident Report - Start Orchestration
# =============================================================================


@app.route(route="incident/report", methods=["POST"])
@app.durable_client_input(client_name="client")
async def report_incident(req: func.HttpRequest, client) -> func.HttpResponse:
    """Start a new incident response orchestration.

    Request body:
    {
        "user_id": "user123",
        "title": "API latency spike in payment service",
        "description": "P99 latency increased from 200ms to 5s...",
        "severity": "critical",
        "affected_service": "payment-api"
    }
    """
    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            body=json.dumps({"error": "Invalid JSON body"}),
            status_code=400,
            mimetype="application/json",
        )

    required_fields = ["title", "description"]
    missing = [f for f in required_fields if not body.get(f)]
    if missing:
        return func.HttpResponse(
            body=json.dumps({"error": f"Missing required fields: {missing}"}),
            status_code=400,
            mimetype="application/json",
        )

    # Default user_id from header or body
    user_id = body.get("user_id") or req.headers.get("x-user-id", "anonymous")
    body["user_id"] = user_id

    instance_id = await client.start_new(
        "incident_response_orchestrator",
        client_input=body,
    )

    logging.info(
        "Started incident response %s: '%s' for user %s",
        instance_id, body.get("title"), user_id,
    )

    return func.HttpResponse(
        body=json.dumps({
            "instance_id": instance_id,
            "status": "started",
            "title": body.get("title"),
        }),
        status_code=202,
        mimetype="application/json",
    )


# =============================================================================
# HITL Decision - Approve/Reject Remediation
# =============================================================================


@app.route(route="incident/{instanceId}/decide", methods=["POST"])
@app.durable_client_input(client_name="client")
async def submit_decision(req: func.HttpRequest, client) -> func.HttpResponse:
    """Submit an approval decision for a waiting incident orchestration.

    Request body:
    {
        "decision": "approve" | "reject",
        "notes": "Optional operator notes"
    }
    """
    instance_id = req.route_params.get("instanceId")

    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            body=json.dumps({"error": "Invalid JSON body"}),
            status_code=400,
            mimetype="application/json",
        )

    decision = body.get("decision")
    if decision not in ("approve", "reject"):
        return func.HttpResponse(
            body=json.dumps({"error": "decision must be 'approve' or 'reject'"}),
            status_code=400,
            mimetype="application/json",
        )

    # Check if instance exists and is running
    status = await client.get_status(instance_id)
    if not status:
        return func.HttpResponse(
            body=json.dumps({"error": "Incident not found"}),
            status_code=404,
            mimetype="application/json",
        )

    if status.runtime_status.name != "Running":
        return func.HttpResponse(
            body=json.dumps({
                "error": "Incident is not waiting for input",
                "status": status.runtime_status.name,
            }),
            status_code=400,
            mimetype="application/json",
        )

    # Raise the external event -- this is what resumes the orchestrator
    await client.raise_event(instance_id, "ApprovalDecision", body)

    logging.info("Decision '%s' submitted for incident %s", decision, instance_id)

    return func.HttpResponse(
        body=json.dumps({
            "instance_id": instance_id,
            "status": "decision_submitted",
            "decision": decision,
        }),
        status_code=200,
        mimetype="application/json",
    )


# =============================================================================
# Incident Status - Poll current state
# =============================================================================


@app.route(route="incident/{instanceId}/status", methods=["GET"])
@app.durable_client_input(client_name="client")
async def get_incident_status(req: func.HttpRequest, client) -> func.HttpResponse:
    """Get the current status of an incident orchestration."""
    instance_id = req.route_params.get("instanceId")

    status = await client.get_status(instance_id, show_input=True)
    if not status:
        return func.HttpResponse(
            body=json.dumps({"error": "Incident not found"}),
            status_code=404,
            mimetype="application/json",
        )

    return func.HttpResponse(
        body=json.dumps({
            "instance_id": instance_id,
            "runtime_status": status.runtime_status.name,
            "custom_status": status.custom_status,
            "input": status.input_ if hasattr(status, "input_") else None,
            "output": status.output if hasattr(status, "output") else None,
            "created_time": status.created_time.isoformat() if status.created_time else None,
            "last_updated_time": status.last_updated_time.isoformat() if status.last_updated_time else None,
        }),
        status_code=200,
        mimetype="application/json",
    )


# =============================================================================
# List All Incidents
# =============================================================================


@app.route(route="incidents", methods=["GET"])
@app.durable_client_input(client_name="client")
async def list_incidents(req: func.HttpRequest, client) -> func.HttpResponse:
    """List all incident orchestration instances."""
    try:
        instances = await client.get_status_all()
    except Exception as e:
        logging.warning("get_status_all failed: %s", e)
        instances = []

    results = []
    for inst in instances:
        # Only include our orchestrator instances
        name = getattr(inst, "name", None) or ""
        if name and name != "incident_response_orchestrator":
            continue
        results.append({
            "instance_id": inst.instance_id,
            "runtime_status": inst.runtime_status.name if inst.runtime_status else None,
            "custom_status": inst.custom_status,
            "created_time": inst.created_time.isoformat() if inst.created_time else None,
            "last_updated_time": inst.last_updated_time.isoformat() if inst.last_updated_time else None,
            "input": inst.input_ if hasattr(inst, "input_") else None,
        })

    # Sort by created_time descending (newest first)
    results.sort(key=lambda x: x.get("created_time") or "", reverse=True)

    return func.HttpResponse(
        body=json.dumps(results),
        status_code=200,
        mimetype="application/json",
    )


# =============================================================================
# Discover MCP tools (temporary helper)
# =============================================================================


@app.route(route="mcp-discover", methods=["GET"])
async def discover_mcp_tools(req: func.HttpRequest) -> func.HttpResponse:
    """Discover available tools on configured MCP servers.

    Uses the DirectMCPClient (plain HTTP) with MI auth for Azure MCP.
    """
    from mcp_tools import DirectMCPClient

    results = {}

    # ---- Learn MCP ----
    try:
        lc = DirectMCPClient(LEARN_MCP_URL)
        await lc.ensure_initialized()
        lr = await lc._send_request("tools/list")
        results["learn_mcp"] = {
            "url": LEARN_MCP_URL,
            "tools": lr.get("result", {}).get("tools", []) if lr else [],
        }
    except Exception as exc:
        results["learn_mcp"] = {"error": str(exc)}

    # ---- Azure MCP ----
    if AZURE_MCP_SERVER_URL:
        try:
            from azure.identity.aio import (
                DefaultAzureCredential as AsyncDefaultAzureCredential,
            )

            cred = AsyncDefaultAzureCredential()
            scope = f"api://{AZURE_MCP_APP_ID}/.default" if AZURE_MCP_APP_ID else None
            token = await cred.get_token(scope) if scope else None

            headers = {}
            if token:
                headers["Authorization"] = f"Bearer {token.token}"

            http = _httpx.AsyncClient(
                headers=headers,
                timeout=_httpx.Timeout(30.0, read=60.0),
            )
            ac = DirectMCPClient(AZURE_MCP_SERVER_URL, http)
            await ac.ensure_initialized()
            ar = await ac._send_request("tools/list")
            tool_list = ar.get("result", {}).get("tools", []) if ar else []
            results["azure_mcp"] = {
                "url": AZURE_MCP_SERVER_URL,
                "tools": [
                    {"name": t.get("name"), "description": t.get("description", "")[:120]}
                    for t in tool_list
                ],
                "total_tools": len(tool_list),
            }
            await cred.close()
        except Exception as exc:
            results["azure_mcp"] = {"url": AZURE_MCP_SERVER_URL, "error": str(exc)}
    else:
        results["azure_mcp"] = {"status": "not_configured"}

    return func.HttpResponse(
        body=json.dumps(results, indent=2),
        status_code=200,
        mimetype="application/json",
    )
