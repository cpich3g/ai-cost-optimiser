"""Durable orchestrator for AI-powered incident response with HITL approval.

This is the star of the show: an orchestrator that
  1. Receives an incident report (with optional Azure resource identifiers)
  2. Uses an AI agent (via Microsoft Agent Framework) with MCP tools to:
     - Query live Azure Monitor metrics, logs, and Advisor recommendations
     - Search Microsoft Learn docs for troubleshooting guidance
  3. Streams progress to the frontend via SignalR
  4. PAUSES for human approval (HITL) -- survives restarts, can wait for days
  5. On approval, *simulates* remediation steps (faux execution for demo)
  6. Handles rejection and timeout gracefully
"""

import json
import logging
import re
from datetime import timedelta

from config import APPROVAL_TIMEOUT_HOURS, ENABLE_MCP_TOOLS


def _extract_json(text: str) -> dict:
    """Best-effort extraction of a JSON object from an AI response.

    Handles common quirks:
      - Markdown code fences (```json ... ```)
      - Leading/trailing whitespace or prose before/after the JSON block
    Raises json.JSONDecodeError if no valid JSON object can be found.
    """
    # 1. Try parsing the raw text first
    stripped = text.strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass

    # 2. Strip markdown code fences (```json ... ``` or ``` ... ```)
    fence_pattern = r"```(?:json)?\s*\n?(.*?)\n?\s*```"
    match = re.search(fence_pattern, stripped, re.DOTALL)
    if match:
        try:
            return json.loads(match.group(1).strip())
        except json.JSONDecodeError:
            pass

    # 3. Find the first { ... } block (greedy outermost braces)
    brace_match = re.search(r"\{.*\}", stripped, re.DOTALL)
    if brace_match:
        return json.loads(brace_match.group(0))

    raise json.JSONDecodeError("No JSON object found", text, 0)


def register_orchestrator(app):
    """Register the incident response orchestrator with the app."""

    @app.orchestration_trigger(context_name="context")
    def incident_response_orchestrator(context):
        """Durable orchestrator: AI analysis (with MCP) -> HITL approval -> faux remediation.

        Input:
        {
            "user_id": str,
            "title": str,
            "description": str,
            "severity": str,            # "critical" | "high" | "medium" | "low"
            "affected_service": str,
            "resource_group": str,       # optional - Azure RG for live diagnostics
            "resource_name": str         # optional - Azure resource for live diagnostics
        }
        """
        input_data = context.get_input()
        instance_id = context.instance_id
        user_id = input_data.get("user_id", "anonymous")

        # Incident metadata to persist in custom_status
        incident_meta = {
            "title": input_data.get("title", "Untitled"),
            "severity": input_data.get("severity", "unknown"),
            "affected_service": input_data.get("affected_service", ""),
        }

        # Optional Azure resource identifiers for MCP-powered diagnostics
        resource_group = input_data.get("resource_group", "")
        resource_name = input_data.get("resource_name", "")

        # Helper to send SignalR notifications
        def notify(event: str, data: dict):
            return context.call_activity(
                "notify_user",
                {
                    "user_id": user_id,
                    "instance_id": instance_id,
                    "event": event,
                    "data": data,
                },
            )

        # =====================================================================
        # Step 1: Acknowledge incident received
        # =====================================================================
        context.set_custom_status({
            "stage": "received",
            "message": "Incident report received",
            **incident_meta,
        })
        yield notify("incident_received", {
            "title": input_data.get("title", ""),
            "severity": input_data.get("severity", "unknown"),
            "affected_service": input_data.get("affected_service", ""),
        })

        # =====================================================================
        # Step 2: Run AI analysis via Agent Framework + MCP tools
        # =====================================================================
        context.set_custom_status({
            "stage": "analyzing",
            "message": "AI agent is analyzing the incident with live Azure diagnostics...",
            **incident_meta,
        })
        yield notify("analysis_started", {
            "message": "AI incident analyzer is querying Azure Monitor, searching docs, and correlating data...",
        })

        # Use the Agent Framework pattern: get_agent -> run -> yield
        analyzer = app.get_agent(context, "IncidentAnalyzer")
        analyzer_thread = analyzer.get_new_thread()

        # Build analysis prompt — adapt based on whether MCP tools are available
        azure_context_section = ""
        if ENABLE_MCP_TOOLS:
            if resource_group and resource_name:
                azure_context_section = (
                    f"\nAZURE RESOURCE DETAILS:\n"
                    f"  Resource Group: {resource_group}\n"
                    f"  Resource Name: {resource_name}\n\n"
                    f"IMPORTANT: Use your Azure MCP tools to:\n"
                    f"  1. Query Azure Monitor for recent metrics and log entries for this resource\n"
                    f"  2. Check Azure Advisor for any active recommendations\n"
                    f"  3. Check App Service / Compute status as appropriate\n"
                    f"  4. Look at Service Health for any ongoing platform issues\n"
                )
            elif resource_group:
                azure_context_section = (
                    f"\nAZURE RESOURCE DETAILS:\n"
                    f"  Resource Group: {resource_group}\n\n"
                    f"Use Azure MCP tools to check the resource group for recent issues.\n"
                )
        else:
            if resource_group:
                azure_context_section = (
                    f"\nAZURE RESOURCE CONTEXT:\n"
                    f"  Resource Group: {resource_group}\n"
                    + (f"  Resource Name: {resource_name}\n" if resource_name else "")
                )

        tool_instruction = ""
        if ENABLE_MCP_TOOLS:
            tool_instruction = (
                "ALSO: Use microsoft_docs_search to find relevant troubleshooting articles "
                "from Microsoft Learn for this type of issue.\n\n"
            )

        analysis_prompt = (
            f"Analyze this production incident and provide your assessment.\n\n"
            f"Title: {input_data.get('title', 'Unknown')}\n"
            f"Description: {input_data.get('description', 'No description')}\n"
            f"Severity: {input_data.get('severity', 'unknown')}\n"
            f"Affected Service: {input_data.get('affected_service', 'unknown')}\n"
            f"{azure_context_section}\n"
            f"{tool_instruction}"
            f"Respond with a JSON object containing:\n"
            f"- diagnosis: string (detailed diagnosis of the issue)\n"
            f"- root_cause: string (identified root cause)\n"
            f"- severity_assessment: string (your severity assessment: critical/high/medium/low)\n"
            f"- confidence: number (0-100, your confidence in the diagnosis)\n"
            f"- azure_findings: list of strings (key observations and likely Azure-related findings)\n"
            f"- doc_references: list of objects with 'title' and 'url' (relevant MS Learn articles)\n"
            f"- logs_analyzed: list of strings (log sources that should be examined)\n"
            f"- metrics_checked: list of strings (metrics that should be examined)\n"
            f"- remediation_steps: list of objects, each with:\n"
            f"    - step_number: number\n"
            f"    - action: string (what to do)\n"
            f"    - risk_level: string (low/medium/high)\n"
            f"    - estimated_impact: string (expected outcome)\n\n"
            f"Return ONLY the JSON object, no markdown formatting."
        )

        analysis_response = yield analyzer.run(
            messages=analysis_prompt,
            thread=analyzer_thread,
        )

        # Parse the AI response
        analysis_text = analysis_response.text if analysis_response else ""
        if not analysis_text:
            analysis_text = ""

        # If .text is empty, the agent may have returned error-type content.
        # Content.from_error() creates type="error" which is invisible to .text
        # (it only joins type="text" content). Extract error details explicitly.
        if not analysis_text.strip() and analysis_response:
            error_parts = []
            for msg in getattr(analysis_response, "messages", []):
                for content in getattr(msg, "contents", []):
                    if getattr(content, "type", None) == "error":
                        err_msg = getattr(content, "message", "") or ""
                        err_code = getattr(content, "error_code", "") or ""
                        err_detail = getattr(content, "error_details", "") or ""
                        error_parts.append(
                            f"[{err_code}] {err_msg}"
                            + (f" | details: {err_detail}" if err_detail else "")
                        )
            if error_parts:
                analysis_text = "; ".join(error_parts)
                logging.warning(
                    "Agent returned error content for %s: %s",
                    instance_id,
                    analysis_text[:2000],
                )

        logging.info(
            "IncidentAnalyzer response for %s (len=%d): %s",
            instance_id,
            len(analysis_text),
            analysis_text[:500],
        )

        try:
            analysis = _extract_json(analysis_text)
            logging.info(
                "Successfully parsed JSON analysis for %s (keys: %s)",
                instance_id,
                list(analysis.keys()),
            )
        except (json.JSONDecodeError, TypeError, AttributeError) as exc:
            logging.warning(
                "Failed to parse analysis JSON for %s (%s). Raw text length: %d",
                instance_id,
                exc,
                len(analysis_text),
            )
            # Build a meaningful fallback from the raw AI text + incident data
            fallback_diagnosis = analysis_text.strip() if analysis_text.strip() else (
                f"Automated analysis was unable to produce structured results for this incident. "
                f"The incident involves {input_data.get('affected_service', 'an unspecified service')} "
                f"with reported severity '{input_data.get('severity', 'unknown')}'. "
                f"Description: {input_data.get('description', 'No description provided.')} "
                f"Manual investigation is recommended."
            )
            analysis = {
                "diagnosis": fallback_diagnosis,
                "root_cause": f"Requires manual investigation — AI analysis returned non-structured output",
                "severity_assessment": input_data.get("severity", "unknown"),
                "confidence": 30,
                "azure_findings": [],
                "doc_references": [],
                "logs_analyzed": [],
                "metrics_checked": [],
                "remediation_steps": [
                    {
                        "step_number": 1,
                        "action": f"Investigate {input_data.get('affected_service', 'the affected service')} manually — check recent deployments, resource health, and logs",
                        "risk_level": "low",
                        "estimated_impact": "Identify actual root cause",
                    },
                    {
                        "step_number": 2,
                        "action": "Review Azure Monitor metrics and alerts for anomalies in the affected time window",
                        "risk_level": "low",
                        "estimated_impact": "Correlate symptoms with infrastructure signals",
                    },
                    {
                        "step_number": 3,
                        "action": "Apply targeted remediation based on manual findings (restart, scale, rollback, etc.)",
                        "risk_level": "medium",
                        "estimated_impact": "Restore service availability",
                    },
                ],
            }

        # =====================================================================
        # Step 3: Send analysis results + request approval
        # =====================================================================
        remediation_steps = analysis.get("remediation_steps", [])

        # Keep custom_status small (16 KB limit) -- full details go via SignalR
        analysis_summary = {
            "root_cause": analysis.get("root_cause", ""),
            "severity_assessment": analysis.get("severity_assessment", ""),
            "confidence": analysis.get("confidence", 0),
            "num_remediation_steps": len(remediation_steps),
            "num_azure_findings": len(analysis.get("azure_findings", [])),
            "num_doc_references": len(analysis.get("doc_references", [])),
        }

        # Include enough detail for the dashboard to render the full plan
        analysis_detail = {
            "diagnosis": analysis.get("diagnosis", ""),
            "remediation_steps": remediation_steps,
            "azure_findings": analysis.get("azure_findings", []),
            "doc_references": analysis.get("doc_references", []),
        }

        context.set_custom_status({
            "stage": "awaiting_approval",
            "message": "Analysis complete. Waiting for human approval.",
            **incident_meta,
            "analysis_summary": analysis_summary,
            "analysis_detail": analysis_detail,
        })

        yield notify("analysis_complete", {
            "diagnosis": analysis.get("diagnosis", ""),
            "root_cause": analysis.get("root_cause", ""),
            "severity_assessment": analysis.get("severity_assessment", ""),
            "confidence": analysis.get("confidence", 0),
            "azure_findings": analysis.get("azure_findings", []),
            "doc_references": analysis.get("doc_references", []),
            "logs_analyzed": analysis.get("logs_analyzed", []),
            "metrics_checked": analysis.get("metrics_checked", []),
        })

        yield notify("approval_required", {
            "message": "Review the analysis and approve or reject the remediation plan.",
            "remediation_steps": remediation_steps,
            "timeout_hours": APPROVAL_TIMEOUT_HOURS,
        })

        # =====================================================================
        # Step 4: THE HITL PAUSE -- wait_for_external_event + timeout
        #
        # This is the magic of Durable Functions: the orchestrator checkpoints
        # here and the process can restart, scale down, or crash. When the human
        # eventually clicks "Approve" or "Reject" (minutes, hours, or days later),
        # the framework replays the orchestrator to this point and continues.
        # =====================================================================
        approval_event = context.wait_for_external_event("ApprovalDecision")
        timeout = context.create_timer(
            context.current_utc_datetime + timedelta(hours=APPROVAL_TIMEOUT_HOURS)
        )
        winner = yield context.task_any([approval_event, timeout])

        # =====================================================================
        # Step 5/6/7: Handle the decision
        # =====================================================================
        if winner == timeout:
            # TIMEOUT -- no response within the approval window
            context.set_custom_status({
                "stage": "expired",
                "message": "Approval request expired",
                **incident_meta,
                "analysis_summary": analysis_summary,
                "analysis_detail": analysis_detail,
            })
            yield notify("approval_expired", {
                "message": f"No response received within {APPROVAL_TIMEOUT_HOURS} hours. "
                           f"The remediation plan has been discarded.",
            })
            return {
                "status": "expired",
                "reason": f"No approval within {APPROVAL_TIMEOUT_HOURS} hours",
            }

        # Cancel the timeout since we got a response
        timeout.cancel()

        decision_data = approval_event.result
        if isinstance(decision_data, str):
            try:
                decision_data = json.loads(decision_data)
            except json.JSONDecodeError:
                decision_data = {"decision": decision_data}

        decision = decision_data.get("decision", "reject")
        approver_notes = decision_data.get("notes", "")

        if decision != "approve":
            # REJECTED
            context.set_custom_status({
                "stage": "rejected",
                "message": "Remediation plan was rejected",
                **incident_meta,
                "analysis_summary": analysis_summary,
                "analysis_detail": analysis_detail,
            })
            yield notify("remediation_rejected", {
                "message": "The remediation plan was rejected by the operator.",
                "notes": approver_notes,
            })
            return {
                "status": "rejected",
                "notes": approver_notes,
            }

        # =====================================================================
        # Step 5: APPROVED -- Simulate remediation (faux execution for demo)
        #
        # Each step is "executed" with a short delay and always succeeds.
        # This lets us demo the full flow repeatedly without side-effects.
        # =====================================================================
        context.set_custom_status({
            "stage": "remediating",
            "message": "Executing approved remediation plan...",
            **incident_meta,
            "analysis_summary": analysis_summary,
            "analysis_detail": analysis_detail,
            "completed_steps": 0,
            "total_steps": len(remediation_steps),
        })
        yield notify("remediation_started", {
            "message": "Remediation approved! Executing steps...",
            "total_steps": len(remediation_steps),
            "approver_notes": approver_notes,
        })

        completed_steps = []

        for i, step in enumerate(remediation_steps):
            step_number = step.get("step_number", i + 1)
            action = step.get("action", f"Step {step_number}")
            risk_level = step.get("risk_level", "medium")

            # Notify frontend about current step
            yield notify("remediation_step", {
                "step_number": step_number,
                "action": action,
                "risk_level": risk_level,
                "status": "in_progress",
                "total_steps": len(remediation_steps),
            })

            # Simulate execution with a short delay (3 seconds per step)
            yield context.create_timer(
                context.current_utc_datetime + timedelta(seconds=3)
            )

            # Faux result -- always succeeds for demo purposes
            step_result = {
                "step_number": step_number,
                "action": action,
                "risk_level": risk_level,
                "status": "success",
                "output": f"Successfully executed: {action}",
                "details": "Simulated execution completed without errors.",
            }
            completed_steps.append(step_result)

            # Update custom status with progress (keep payload small)
            context.set_custom_status({
                "stage": "remediating",
                "message": f"Completed step {step_number} of {len(remediation_steps)}",
                **incident_meta,
                "analysis_summary": analysis_summary,
                "analysis_detail": analysis_detail,
                "completed_steps": len(completed_steps),
                "total_steps": len(remediation_steps),
            })

            # Notify frontend about step completion
            yield notify("remediation_step", {
                **step_result,
                "total_steps": len(remediation_steps),
            })

        # =====================================================================
        # Step 8: Final status -- incident resolved
        # =====================================================================
        context.set_custom_status({
            "stage": "resolved",
            "message": "Incident remediation complete",
            **incident_meta,
            "analysis_summary": analysis_summary,
            "analysis_detail": analysis_detail,
            "completed_steps": len(completed_steps),
            "total_steps": len(remediation_steps),
        })

        yield notify("incident_resolved", {
            "message": "All remediation steps have been executed successfully.",
            "completed_steps": completed_steps,
            "total_steps": len(remediation_steps),
        })

        return {
            "status": "resolved",
            "analysis_summary": analysis_summary,
            "completed_steps_count": len(completed_steps),
        }

    return incident_response_orchestrator
