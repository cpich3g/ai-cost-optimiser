<#
.SYNOPSIS
    Deploy the AI Incident Responder to Azure.
.DESCRIPTION
    1. Creates the Durable Task Scheduler + Task Hub via REST API
    2. Deploys VNet, Storage (MI + PE), ASP, Function App via Bicep
    3. Assigns Cognitive Services + Scheduler RBAC (cross-RG)
    4. Deploys the function app code via remote build
    5. Restarts and verifies the function app
#>

param(
    [string]$ResourceGroup        = "rg-durableagents-hitl",
    [string]$Location             = "swedencentral",
    [string]$BaseName             = "durableagentshitl",
    [string]$FoundryResourceGroup = "epicaidevdemo",
    [string]$FoundryAccountName   = "ai-justinjoy-4099",
    [string]$DeploymentName       = "gpt-4.1"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$schedulerName = "scheduler-$BaseName"
$taskHubName   = "default"
$subId         = (az account show --query "id" -o tsv)

# =========================================================================
# Step 1/6: Create Durable Task Scheduler
# =========================================================================
Write-Host "`n=== Step 1/6: Create Durable Task Scheduler ===" -ForegroundColor Cyan

$schedulerUrl = "https://management.azure.com/subscriptions/$subId/resourceGroups/$ResourceGroup/providers/Microsoft.DurableTask/schedulers/${schedulerName}?api-version=2025-04-01-preview"

$schedulerBodyFile = [System.IO.Path]::GetTempFileName()
$schedulerJson = '{"location":"' + $Location + '","properties":{"ipAllowlist":[],"sku":{"name":"Dedicated","capacity":1}}}'
[System.IO.File]::WriteAllText($schedulerBodyFile, $schedulerJson, [System.Text.UTF8Encoding]::new($false))

Write-Host "Creating scheduler: $schedulerName ..."
az rest --method put --url $schedulerUrl --body "@$schedulerBodyFile" -o none 2>&1
if ($LASTEXITCODE -ne 0) { Write-Warning "Scheduler creation returned non-zero, may already exist or be provisioning." }
Remove-Item $schedulerBodyFile -Force -ErrorAction SilentlyContinue

Write-Host "Waiting for scheduler provisioning..."
$maxWait = 300; $waited = 0
do {
    Start-Sleep -Seconds 10; $waited += 10
    $state = az rest --method get --url $schedulerUrl --query "properties.provisioningState" -o tsv 2>$null
    Write-Host "  Scheduler state: $state ($waited s)"
} while ($state -ne "Succeeded" -and $waited -lt $maxWait)

if ($state -ne "Succeeded") {
    Write-Error "Scheduler did not reach Succeeded state within ${maxWait}s. Current: $state"
}

# =========================================================================
# Step 2/6: Create Task Hub
# =========================================================================
Write-Host "`n=== Step 2/6: Create Task Hub ===" -ForegroundColor Cyan

$taskHubUrl = "https://management.azure.com/subscriptions/$subId/resourceGroups/$ResourceGroup/providers/Microsoft.DurableTask/schedulers/${schedulerName}/taskhubs/${taskHubName}?api-version=2025-04-01-preview"

$taskHubBodyFile = [System.IO.Path]::GetTempFileName()
[System.IO.File]::WriteAllText($taskHubBodyFile, '{"properties":{}}', [System.Text.UTF8Encoding]::new($false))

Write-Host "Creating task hub: $taskHubName ..."
az rest --method put --url $taskHubUrl --body "@$taskHubBodyFile" -o none 2>&1
Remove-Item $taskHubBodyFile -Force -ErrorAction SilentlyContinue

Start-Sleep -Seconds 10
$thState = az rest --method get --url $taskHubUrl --query "properties.provisioningState" -o tsv 2>$null
Write-Host "Task hub state: $thState"

# Get scheduler endpoint and construct connection string
Write-Host "Retrieving scheduler endpoint..."
$schedulerEndpoint = az rest --method get --url $schedulerUrl --query "properties.endpoint" -o tsv
$durableConnStr = "Endpoint=$schedulerEndpoint;Authentication=ManagedIdentity"
Write-Host "Scheduler connection string: $durableConnStr"

# =========================================================================
# Step 3/6: Deploy Bicep (VNet + Storage/PE + ASP + Function App + RBAC)
# =========================================================================
Write-Host "`n=== Step 3/6: Deploy Bicep (VNet + Storage + PE + ASP + Function App + RBAC) ===" -ForegroundColor Cyan

$signalRConnStr = az signalr key list -n durableagents01 -g $ResourceGroup --query "primaryConnectionString" -o tsv
$openAiEndpoint = az cognitiveservices account show -n $FoundryAccountName -g $FoundryResourceGroup --query "properties.endpoint" -o tsv

$outputs = az deployment group create `
    --resource-group $ResourceGroup `
    --template-file infra/main.bicep `
    --parameters `
        signalRConnectionString=$signalRConnStr `
        azureOpenAiEndpoint=$openAiEndpoint `
        azureOpenAiDeploymentName=$DeploymentName `
        durableTaskConnectionString=$durableConnStr `
    --query "properties.outputs" -o json | ConvertFrom-Json

$funcAppName     = $outputs.functionAppName.value
$principalId     = $outputs.principalId.value
$hostName        = $outputs.functionAppHostName.value
$storageAcctName = $outputs.storageAccountName.value

Write-Host "Function App : $funcAppName"
Write-Host "Host         : $hostName"
Write-Host "Principal ID : $principalId"
Write-Host "Storage      : $storageAcctName (MI auth, no shared keys)"
Write-Host "VNet         : $($outputs.vnetName.value)"

# =========================================================================
# Step 4/6: Assign Cross-RG RBAC (Foundry + Scheduler)
# =========================================================================
Write-Host "`n=== Step 4/6: Assign Cross-RG RBAC (Foundry + Scheduler) ===" -ForegroundColor Cyan

# Cognitive Services OpenAI User on Foundry
$foundryScope = "/subscriptions/$subId/resourceGroups/$FoundryResourceGroup/providers/Microsoft.CognitiveServices/accounts/$FoundryAccountName"
Write-Host "Assigning 'Cognitive Services OpenAI User' on $FoundryAccountName ..."
az role assignment create `
    --assignee-object-id $principalId `
    --assignee-principal-type ServicePrincipal `
    --role "5e0bd9bd-7b93-4f28-af87-19fc36ad61bd" `
    --scope $foundryScope `
    -o none 2>&1

# Contributor on Scheduler
$schedulerScope = "/subscriptions/$subId/resourceGroups/$ResourceGroup/providers/Microsoft.DurableTask/schedulers/$schedulerName"
Write-Host "Assigning 'Contributor' on scheduler $schedulerName ..."
az role assignment create `
    --assignee-object-id $principalId `
    --assignee-principal-type ServicePrincipal `
    --role "Contributor" `
    --scope $schedulerScope `
    -o none 2>&1

Write-Host "RBAC roles assigned. Waiting 30s for propagation..."
Start-Sleep -Seconds 30

# =========================================================================
# Step 5/6: Deploy Function App Code (remote build)
# =========================================================================
Write-Host "`n=== Step 5/6: Deploy Function App Code (remote build) ===" -ForegroundColor Cyan

func azure functionapp publish $funcAppName --build remote --python

# =========================================================================
# Step 6/6: Restart & Verify
# =========================================================================
Write-Host "`n=== Step 6/6: Restart & Verify ===" -ForegroundColor Cyan

az functionapp restart --name $funcAppName --resource-group $ResourceGroup
Write-Host "Waiting 60s for restart..."
Start-Sleep -Seconds 60

$funcCount = (az functionapp function list --name $funcAppName --resource-group $ResourceGroup --query "length(@)" -o tsv)
Write-Host "Functions loaded: $funcCount"

Write-Host "`n=== Deployment Complete ===" -ForegroundColor Green
Write-Host "Function App URL : https://$hostName"
Write-Host "UI               : https://$hostName/api/index"
Write-Host "Storage auth     : Managed Identity (no shared keys)"
Write-Host "Networking       : VNet integrated with private endpoints"
Write-Host ""
Write-Host "Note: RBAC propagation may take up to 10 minutes for full effect."
