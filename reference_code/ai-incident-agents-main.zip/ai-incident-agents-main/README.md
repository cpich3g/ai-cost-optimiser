# AI Incident Responder

> **Azure Durable Functions** × **Microsoft Agent Framework** × **Human-in-the-Loop** × **MCP Tools**

A production-ready sample demonstrating an end-to-end AI incident response system. Two AI agents analyze production incidents using live Azure telemetry via **Model Context Protocol (MCP)** tools, stream progress in real time through **SignalR**, then **pause for human approval** before executing remediation. The operator can close their browser, walk away for hours or days, and the durable orchestration **resumes exactly where it left off**.

---

## Architecture

```mermaid
flowchart TB
    subgraph Frontend["Next.js Dashboard"]
        UI["Incident Form<br/>Approval Panel<br/>Event Log<br/>Flow Timeline"]
    end

    subgraph Functions["Azure Durable Functions (Python)"]
        direction TB
        API["HTTP Endpoints<br/>/report · /decide · /status · /list"]
        ORCH["Durable Orchestrator<br/>incident_response"]
        SIG["SignalR Activity<br/>send_signalr_notification"]
        
        subgraph Agents["Microsoft Agent Framework"]
            A1["🔍 IncidentAnalyzer<br/><i>gpt-5.2</i>"]
            A2["🛠️ RemediationExecutor<br/><i>gpt-5.2</i>"]
        end
    end

    subgraph MCP["MCP Tool Servers"]
        direction TB
        LEARN["Microsoft Learn MCP<br/><i>learn.microsoft.com/api/mcp</i>"]
        AZURE["Azure MCP Server<br/><i>Container App + Managed Identity</i>"]
    end

    subgraph Azure["Azure Services"]
        AOAI["Azure OpenAI<br/>gpt-5.2"]
        SIGNALR["Azure SignalR Service<br/>Serverless Mode"]
        DTS["Durable Task Scheduler<br/>State Persistence"]
    end

    UI -- "POST /report" --> API
    UI -- "POST /decide" --> API
    UI -- "GET /status · /list" --> API
    API --> ORCH
    ORCH --> A1
    ORCH --> A2
    ORCH --> SIG
    SIG --> SIGNALR
    SIGNALR -- "Real-time events" --> UI
    A1 --> AOAI
    A2 --> AOAI
    A1 -- "JSON-RPC" --> LEARN
    A1 -- "JSON-RPC + Entra ID" --> AZURE
    ORCH --> DTS
```

---

## Dashboard

The Next.js dashboard provides a three-panel layout for managing the full incident lifecycle: submit incidents (left), view AI analysis and approve/reject remediation plans (center), and monitor live activity via SignalR (right).

### Resolved Incident — Full Pipeline

A critical "Production VM unresponsive" incident that progressed through all five stages: Received → AI Analyzing → Awaiting Approval → Remediating → Resolved. The flow timeline shows green checkmarks for every completed stage.

![Dashboard overview showing a resolved incident with flow timeline, incident details, and live activity](images/dashboard-overview.png)

### AI Analysis — Root Cause & Confidence

The AI agent produces a structured diagnosis with root cause summary, confidence score (0–100%), severity assessment, and a multi-step remediation plan with risk levels per step.

![AI analysis showing root cause, 80% confidence bar, severity assessment, and start of remediation plan](images/ai-analysis.png)

### Remediation Plan — Risk-Rated Steps

Each remediation step includes a risk badge (low / medium / high) and an impact statement so the operator can make an informed approval decision.

![Remediation plan with risk-rated steps showing low, medium, and high risk badges](images/remediation-plan.png)

### Azure Findings & Documentation

Live Azure telemetry findings from MCP tools and auto-linked Microsoft Learn documentation articles relevant to the incident.

![Azure findings list and documentation links from MCP tools](images/azure-findings.png)

### Rejected Incident — Human-in-the-Loop

When an operator rejects a remediation plan, the flow timeline shows a red "Rejected" badge and the live activity panel reflects the decision. The orchestration ends gracefully — no remediation steps are executed.

![Rejected incident showing red Rejected badge in flow timeline and rejection status in live activity](images/rejected-incident.png)

---

## Orchestrator Flow — Stage by Stage

The durable orchestrator manages the full incident lifecycle through **7 stages**, each checkpointed for durability:

```mermaid
stateDiagram-v2
    [*] --> received: POST /report
    received --> analyzing: AI analysis begins
    analyzing --> awaiting_approval: Analysis complete
    awaiting_approval --> approved: Human approves
    awaiting_approval --> rejected: Human rejects
    awaiting_approval --> expired: 72h timeout
    approved --> remediating: Execute remediation
    remediating --> resolved: All steps complete
    rejected --> [*]
    expired --> [*]
    resolved --> [*]
```

| Stage | What Happens | Implementation |
|-------|-------------|----------------|
| **① received** | Incident report is submitted. Orchestrator starts, generates `instance_id`, sends `incident_received` via SignalR. | `context.set_custom_status({"stage": "received"})` |
| **② analyzing** | `IncidentAnalyzer` agent examines the incident using Azure OpenAI (gpt-5.2). If MCP tools are enabled, the agent can query live Azure telemetry — monitor metrics, resource health, App Insights logs, advisor recommendations, and more. | `context.call_activity("run_agent", agent="IncidentAnalyzer")` |
| **③ awaiting_approval** | Analysis is parsed into structured JSON (root cause, severity, confidence, remediation steps). Full details stream via SignalR; a summary is kept in `custom_status` (16 KB limit). The orchestrator **pauses** with `wait_for_external_event("ApprovalDecision")`. | `task_any([wait_for_external_event, create_timer(72h)])` |
| **④ approved / rejected / expired** | Human reviews the analysis in the dashboard and clicks Approve or Reject. If no decision within 72 hours, the orchestration expires automatically. | `raise_event("ApprovalDecision", {"decision": "approve"})` |
| **⑤ remediating** | Each remediation step executes sequentially with 3-second simulated delays. Progress streams step-by-step via SignalR. | Loop over `remediation_steps` with `create_timer` |
| **⑥ resolved** | All steps complete. Final status written, `incident_resolved` event sent. | `context.set_custom_status({"stage": "resolved"})` |

### The HITL Pause — How It Works

The magic of Durable Functions is at stage ③. When the orchestrator calls `wait_for_external_event`, it:

1. **Checkpoints** the entire execution state to the Durable Task Scheduler
2. **Goes dormant** — the Azure Functions runtime releases all resources
3. The process can restart, scale to zero, or even crash — **state is preserved**

When a human submits a decision (even days later):
1. The framework reads the execution history from storage
2. **Replays** the orchestrator from the beginning
3. Completed activities return cached results (no re-execution)
4. At the `wait_for_external_event` call, the event is now available
5. Execution continues from exactly where it left off

---

## AI Agents

This sample uses the **Microsoft Agent Framework** (`agent-framework-core 1.0.0b260210`) to define two specialized agents, both powered by **Azure OpenAI gpt-5.2**:

### 🔍 IncidentAnalyzer

The primary investigation agent. Receives the incident report and produces a structured diagnosis.

**Responsibilities:**
- Analyze the incident's root cause, severity, and blast radius
- Query live Azure telemetry via MCP tools (when enabled)
- Propose a step-by-step remediation plan with risk levels
- Return structured JSON: `root_cause`, `severity`, `confidence`, `remediation_steps[]`

**Dynamic Instructions:** The agent's system prompt is constructed at startup based on which MCP tools are available. When MCP tools are enabled, it receives detailed descriptions of each tool and is instructed to use them for evidence-based diagnosis.

### 🛠️ RemediationExecutor

A focused execution agent that carries out individual remediation steps.

**Responsibilities:**
- Receive a single remediation step and execute it
- Return structured results with status and output details
- Currently simulated for demo safety — in production, this would call Azure APIs

---

## MCP Tool Integration

The sample integrates **11 MCP tools** across two servers using the **Model Context Protocol**. Tools are registered as Agent Framework `@tool` functions that the AI can invoke during analysis.

### Why Direct HTTP Instead of Streaming?

Azure Durable Functions replays orchestrator code on resume. The standard MCP SDK uses **Server-Sent Events (SSE)** with `anyio.TaskGroup`, which **hangs during replay** because the async event loop behaves differently. This sample uses a custom `DirectMCPClient` that makes plain **HTTP POST JSON-RPC** calls — simple, replay-safe, and reliable.

### Microsoft Learn MCP (3 tools)

Public server at `learn.microsoft.com/api/mcp` — no authentication required.

| Tool | Description |
|------|-------------|
| `microsoft_docs_search` | Search Microsoft Learn documentation for relevant articles |
| `microsoft_code_sample_search` | Find code samples from Microsoft Learn |
| `microsoft_docs_fetch` | Fetch full content of a specific documentation page |

### Azure MCP Server (8 tools)

Deployed as an **Azure Container App** with **Managed Identity**. Authenticated via **Entra ID bearer tokens** using `DefaultAzureCredential`.

| Tool | Description |
|------|-------------|
| `azure_monitor_query` | Query Azure Monitor metrics and logs |
| `azure_resource_health` | Check health status of Azure resources |
| `azure_advisor_recommendations` | Get Azure Advisor optimization recommendations |
| `azure_appinsights_query` | Query Application Insights telemetry with KQL |
| `azure_applens_diagnose` | Run App Lens diagnostics on App Service resources |
| `azure_storage_operations` | Inspect storage account configuration and metrics |
| `azure_compute_operations` | Query VM and compute resource status |
| `azure_appservice_operations` | Manage and inspect App Service resources |

### MCP Auth Flow

```
IncidentAnalyzer → @tool function → DirectMCPClient
    → DefaultAzureCredential.get_token(AZURE_MCP_APP_ID)
    → HTTP POST with Bearer token
    → Azure MCP Container App
    → Azure Resource Manager APIs
```

MCP tools can be toggled on/off with the `ENABLE_MCP_TOOLS` environment variable.

---

## Tech Stack

| Layer | Technology | Details |
|-------|-----------|---------|
| **AI Model** | Azure OpenAI | `gpt-5.2` — supports both API key and `DefaultAzureCredential` auth |
| **Agent Framework** | Microsoft Agent Framework | `1.0.0b260210` — `AgentFunctionApp` extends `DFApp` for durable agent hosting |
| **Orchestration** | Azure Durable Functions | Python v2 programming model, Durable Task Scheduler backend |
| **Real-time** | Azure SignalR Service | Serverless mode, `incidenthub` hub |
| **MCP** | Model Context Protocol | Direct HTTP JSON-RPC via custom `DirectMCPClient` |
| **Auth** | Microsoft Entra ID | `DefaultAzureCredential` + Managed Identity for MCP server |
| **Frontend** | Next.js 16 | Tailwind CSS v4, shadcn/ui, Geist fonts, responsive dashboard |
| **Language** | Python 3.12 | Azure Functions Python v2 model |

---

## Prerequisites

- Python 3.10+
- [Azure Functions Core Tools](https://learn.microsoft.com/azure/azure-functions/functions-run-local) v4+
- [Azure SignalR Service](https://learn.microsoft.com/azure/azure-signalr/) (Serverless mode)
- [Azure OpenAI](https://learn.microsoft.com/azure/ai-services/openai/) with a deployed model (e.g., `gpt-5.2`)
- [Durable Task Scheduler](https://learn.microsoft.com/azure/azure-functions/durable/durable-functions-scheduler) or Azurite for local storage
- *(Optional)* [Azure MCP Server](https://github.com/Azure/azure-mcp) on Container Apps for live Azure telemetry tools

## Quick Start

1. **Clone and install dependencies:**

   ```bash
   cd durable-agents-hitl-sample
   python -m venv .venv
   source .venv/bin/activate   # or .venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```

2. **Configure environment:**

   ```bash
   cp local.settings.json.template local.settings.json
   ```

   Edit `local.settings.json` with your values:
   - `AZURE_OPENAI_ENDPOINT` — your Azure OpenAI endpoint
   - `AZURE_OPENAI_CHAT_DEPLOYMENT_NAME` — your deployment name (e.g., `gpt-5.2`)
   - `AZURE_OPENAI_API_KEY` — your API key (or omit to use `DefaultAzureCredential`)
   - `AzureSignalRConnectionString` — your SignalR connection string

3. **Start the Durable Task Scheduler (if using local scheduler):**

   ```bash
   # Option A: Use the Durable Task Scheduler emulator
   docker run -p 8080:8080 mcr.microsoft.com/durable-task/scheduler:latest

   # Option B: Use Azurite for Azure Storage-based backend
   azurite --silent
   ```

4. **Run the function app:**

   ```bash
   func start
   ```

5. **Open the UI:**

   Navigate to [http://localhost:7071/api/index](http://localhost:7071/api/index)

---

## Event-Driven Triggers

The sample uses an HTTP endpoint to start orchestrations, but the orchestrator is decoupled from its trigger. In production, you can auto-start incident response from:

- **Azure Monitor / Alert Rules** — Action Groups invoke a Function when an alert fires
- **Event Grid** — React to Azure resource events, Defender for Cloud security alerts, or custom app events
- **Service Bus / Event Hubs** — Integrate with existing observability pipelines (Datadog, Grafana, custom systems)

See the [companion blog post](blog/post.md) for code examples of each trigger type.

---

## API Reference

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/index` | GET | Serve the frontend UI |
| `/api/negotiate` | POST | SignalR connection handshake |
| `/api/incident/report` | POST | Start a new incident response orchestration |
| `/api/incident/{id}/decide` | POST | Submit approval decision (`approve` / `reject` + optional notes) |
| `/api/incident/{id}/status` | GET | Poll orchestration status and `custom_status` |
| `/api/incidents` | GET | List all orchestration instances |
| `/api/mcp-discover` | GET | List available MCP tools and their descriptions |
| `/api/agents/IncidentAnalyzer/run` | POST | Direct agent endpoint (auto-registered by Agent Framework) |
| `/api/agents/RemediationExecutor/run` | POST | Direct agent endpoint (auto-registered by Agent Framework) |

---

## Project Structure

```
function_app.py                  # App entry point — agents, MCP tools, HTTP endpoints
mcp_tools.py                     # DirectMCPClient + 11 @tool-decorated MCP wrappers
config.py                        # Configuration constants (SignalR, MCP URLs, timeouts)
orchestrators/
  incident_response.py           # Durable orchestrator — 7-stage HITL workflow
activities/
  signalr.py                     # SignalR notification activity
content/
  index.html                     # Lightweight frontend (standalone HTML)
host.json                        # Azure Functions host config + Durable Task settings
requirements.txt                 # Python dependencies
local.settings.json.template     # Environment variable template
blog/
  post.md                        # Companion blog post
```

---

## Tips & Gotchas

### 16 KB Payload Limit

Durable Functions enforces a **16 KB limit** on JSON-serialized payloads for `custom_status`, return values, and activity inputs/outputs. AI agents tend to produce verbose responses, so it's easy to exceed this.

The orchestrator keeps only **summary data** in `custom_status` (root cause, severity, confidence, step counts) and sends full details to the browser via **SignalR notifications**, which have no size limit.

### Deterministic Orchestrator Code

Orchestrator functions are replayed on resume. Never use non-deterministic operations directly:

| ❌ Don't use | ✅ Use instead |
|-----------|-------------|
| `datetime.now()` | `context.current_utc_datetime` |
| `random()` | `context.new_uuid()` |
| Direct HTTP calls | Activities |
| File I/O | Activities |

### MCP + Durable Functions

The standard MCP Python SDK uses SSE streams with `anyio.TaskGroup`, which **hangs during orchestrator replay**. Use plain HTTP JSON-RPC calls (as shown in `mcp_tools.py`) or run MCP interactions exclusively inside **activities**, never in the orchestrator function itself.

---

## Built With

- [Microsoft Agent Framework](https://github.com/microsoft/agent-framework) — Agent abstraction + durable execution
- [Azure Durable Functions](https://learn.microsoft.com/azure/azure-functions/durable/) — Stateful orchestration with HITL
- [Azure SignalR Service](https://learn.microsoft.com/azure/azure-signalr/) — Real-time event streaming
- [Azure OpenAI](https://learn.microsoft.com/azure/ai-services/openai/) — AI-powered incident analysis (gpt-5.2)
- [Model Context Protocol](https://modelcontextprotocol.io/) — Standardized tool integration for AI agents
- [Azure MCP Server](https://github.com/Azure/azure-mcp) — Live Azure telemetry via MCP

## References

- [Azure Functions Python Developer Guide](https://learn.microsoft.com/azure/azure-functions/functions-reference-python)
- [Agent Framework — Azure Functions hosting sample](https://github.com/microsoft/agent-framework/tree/main/python/samples/04-hosting/azure_functions)
- [Agent Framework — Durable Task hosting sample](https://github.com/microsoft/agent-framework/tree/main/python/samples/04-hosting/durabletask)
- [Durable Functions HITL Pattern](https://learn.microsoft.com/azure/azure-functions/durable/durable-functions-overview#human)
- [MCP Specification](https://spec.modelcontextprotocol.io/)
