"""Direct HTTP-based MCP tool wrappers.

These tools call MCP servers via plain HTTP POST (JSON-RPC) instead of using
the ``streamable_http_client`` transport. The streaming transport relies on
anyio TaskGroups + SSE that hang inside Azure Durable Functions entities.
Using simple request/response HTTP avoids this incompatibility entirely.

Each tool is a regular ``@tool``-decorated async function that the Agent
Framework registers with the LLM like any other function tool.
"""

import json
import logging
from typing import Annotated

import httpx

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lightweight MCP-over-HTTP client
# ---------------------------------------------------------------------------

class DirectMCPClient:
    """Makes JSON-RPC calls to an MCP server over plain HTTP POST.

    Unlike ``streamable_http_client``, this creates no persistent SSE
    connection, no anyio TaskGroup, and no background tasks.  Each method
    is a self-contained POST -> parse-response cycle.
    """

    def __init__(self, url: str, http_client: httpx.AsyncClient | None = None):
        self.url = url
        self.client = http_client or httpx.AsyncClient(
            timeout=httpx.Timeout(connect=30.0, read=60.0, write=30.0, pool=30.0)
        )
        self.session_id: str | None = None
        self._request_id = 0
        self._initialized = False

    # -- low-level helpers ---------------------------------------------------

    def _next_id(self) -> int:
        self._request_id += 1
        return self._request_id

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        }
        if self.session_id:
            h["mcp-session-id"] = self.session_id
        return h

    @staticmethod
    def _parse_sse_payload(text: str) -> dict | None:
        """Extract the first ``data:`` JSON object from an SSE text body."""
        for line in text.splitlines():
            if line.startswith("data:"):
                data = line[len("data:"):].strip()
                if data:
                    try:
                        return json.loads(data)
                    except json.JSONDecodeError:
                        continue
        return None

    async def _post(self, body: dict) -> dict | None:
        """POST a JSON-RPC message, handle JSON *or* SSE responses."""
        headers = self._headers()
        resp = await self.client.post(self.url, json=body, headers=headers)

        # Store session ID from any response
        sid = resp.headers.get("mcp-session-id")
        if sid:
            self.session_id = sid

        # 202 Accepted — notification acknowledged, no body
        if resp.status_code == 202:
            return None

        resp.raise_for_status()

        ct = resp.headers.get("content-type", "").lower()
        if ct.startswith("application/json"):
            return resp.json()
        elif ct.startswith("text/event-stream"):
            return self._parse_sse_payload(resp.text)
        else:
            logger.warning("Unexpected content-type from MCP server: %s", ct)
            return None

    async def _send_request(self, method: str, params: dict | None = None) -> dict | None:
        """Send a JSON-RPC *request* (expects a result)."""
        body: dict = {
            "jsonrpc": "2.0",
            "id": self._next_id(),
            "method": method,
        }
        if params:
            body["params"] = params
        return await self._post(body)

    async def _send_notification(self, method: str, params: dict | None = None) -> None:
        """Send a JSON-RPC *notification* (no ``id``, no result expected)."""
        body: dict = {
            "jsonrpc": "2.0",
            "method": method,
        }
        if params:
            body["params"] = params
        await self._post(body)

    # -- public API ----------------------------------------------------------

    async def ensure_initialized(self) -> None:
        """Run the MCP initialize + initialized handshake once."""
        if self._initialized:
            return
        result = await self._send_request("initialize", {
            "protocolVersion": "2025-03-26",
            "capabilities": {},
            "clientInfo": {"name": "DirectMCPClient", "version": "1.0.0"},
        })
        logger.info("MCP init response from %s: %s", self.url, result)
        await self._send_notification("notifications/initialized")
        self._initialized = True

    async def call_tool(self, tool_name: str, arguments: dict) -> str:
        """Call an MCP tool and return its text content as a string."""
        await self.ensure_initialized()
        result = await self._send_request("tools/call", {
            "name": tool_name,
            "arguments": arguments,
        })
        if not result:
            return "(no response from MCP server)"

        # JSON-RPC result envelope: {"jsonrpc":"2.0","id":N,"result":{...}}
        inner = result.get("result", result)

        # MCP CallToolResult: {"content": [{"type":"text","text":"..."}], ...}
        content_list = inner.get("content") if isinstance(inner, dict) else None
        if content_list:
            texts = [
                item.get("text", "")
                for item in content_list
                if isinstance(item, dict) and item.get("type") == "text"
            ]
            if texts:
                return "\n".join(texts)

        # Fallback: return the whole result as JSON string
        return json.dumps(inner, indent=2) if isinstance(inner, dict) else str(inner)


# ---------------------------------------------------------------------------
# Pre-built Learn MCP client (public, no auth)
# ---------------------------------------------------------------------------

_learn_client: DirectMCPClient | None = None


def get_learn_client(url: str, http_client: httpx.AsyncClient | None = None) -> DirectMCPClient:
    """Return (and cache) the Learn MCP client singleton."""
    global _learn_client
    if _learn_client is None:
        _learn_client = DirectMCPClient(url, http_client)
    return _learn_client


# ---------------------------------------------------------------------------
# Pre-built Azure MCP client (requires auth)
# ---------------------------------------------------------------------------

_azure_client: DirectMCPClient | None = None


def get_azure_client(url: str, http_client: httpx.AsyncClient | None = None) -> DirectMCPClient:
    """Return (and cache) the Azure MCP client singleton."""
    global _azure_client
    if _azure_client is None:
        _azure_client = DirectMCPClient(url, http_client)
    return _azure_client


# ---------------------------------------------------------------------------
# Agent Framework tool functions — Learn MCP
# ---------------------------------------------------------------------------

async def microsoft_docs_search(
    query: Annotated[str, "Search query for Microsoft Learn documentation"],
) -> str:
    """Search Microsoft Learn documentation for relevant troubleshooting articles, guides, and reference docs."""
    if _learn_client is None:
        return "(Learn MCP not configured)"
    try:
        return await _learn_client.call_tool("microsoft_docs_search", {"query": query})
    except Exception as exc:
        logger.warning("microsoft_docs_search failed: %s", exc)
        return f"(search failed: {exc})"


async def microsoft_code_sample_search(
    query: Annotated[str, "Search query for code samples"],
) -> str:
    """Search for code samples in Microsoft Learn documentation."""
    if _learn_client is None:
        return "(Learn MCP not configured)"
    try:
        return await _learn_client.call_tool("microsoft_code_sample_search", {"query": query})
    except Exception as exc:
        logger.warning("microsoft_code_sample_search failed: %s", exc)
        return f"(search failed: {exc})"


async def microsoft_docs_fetch(
    url: Annotated[str, "URL of the Microsoft Learn page to fetch"],
) -> str:
    """Fetch content from a specific Microsoft Learn documentation page."""
    if _learn_client is None:
        return "(Learn MCP not configured)"
    try:
        return await _learn_client.call_tool("microsoft_docs_fetch", {"url": url})
    except Exception as exc:
        logger.warning("microsoft_docs_fetch failed: %s", exc)
        return f"(fetch failed: {exc})"


# ---------------------------------------------------------------------------
# Agent Framework tool functions — Azure MCP
# ---------------------------------------------------------------------------
# The Azure MCP server exposes ~55 hierarchical tools, each accepting a
# ``command`` parameter to select a sub-command.  We expose a curated set of
# the most valuable tools for incident response and diagnostics.

async def azure_monitor_query(
    command: Annotated[str, "Sub-command: query_metrics, query_logs, list_metrics, list_tables, list_workspaces, query_workspace_logs"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_id: Annotated[str, "Full ARM resource ID (for metrics queries)"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    workspace_name: Annotated[str, "Log Analytics workspace name (for log queries)"] = "",
    metric_names: Annotated[str, "Comma-separated metric names to query"] = "",
    timespan: Annotated[str, "Time range, e.g. PT1H, PT24H, P7D"] = "PT1H",
    query: Annotated[str, "KQL query string (for log queries)"] = "",
) -> str:
    """Query Azure Monitor metrics and logs. Use to investigate resource performance, errors, and health signals."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_id": resource_id,
        "resource_group": resource_group,
        "workspace_name": workspace_name,
        "metric_names": metric_names,
        "timespan": timespan,
        "query": query,
    }.items() if v}
    try:
        return await _azure_client.call_tool("monitor", params)
    except Exception as exc:
        logger.warning("azure_monitor_query failed: %s", exc)
        return f"(monitor query failed: {exc})"


async def azure_resource_health(
    command: Annotated[str, "Sub-command: get_availability_status, list_availability_statuses, list_events"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    resource_id: Annotated[str, "Full ARM resource ID"] = "",
) -> str:
    """Check Azure resource health and availability status. Shows current health, recent outages, and platform events."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "resource_id": resource_id,
    }.items() if v}
    try:
        return await _azure_client.call_tool("resourcehealth", params)
    except Exception as exc:
        logger.warning("azure_resource_health failed: %s", exc)
        return f"(resource health query failed: {exc})"


async def azure_advisor_recommendations(
    command: Annotated[str, "Sub-command: list_recommendations"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    category: Annotated[str, "Category filter: HighAvailability, Security, Performance, Cost, OperationalExcellence"] = "",
) -> str:
    """Get Azure Advisor recommendations for reliability, performance, security, and cost optimization."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "category": category,
    }.items() if v}
    try:
        return await _azure_client.call_tool("advisor", params)
    except Exception as exc:
        logger.warning("azure_advisor_recommendations failed: %s", exc)
        return f"(advisor query failed: {exc})"


async def azure_appinsights_query(
    command: Annotated[str, "Sub-command: list_components, get_component"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    name: Annotated[str, "Application Insights component name"] = "",
) -> str:
    """Query Application Insights components for application telemetry and monitoring data."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "name": name,
    }.items() if v}
    try:
        return await _azure_client.call_tool("applicationinsights", params)
    except Exception as exc:
        logger.warning("azure_appinsights_query failed: %s", exc)
        return f"(appinsights query failed: {exc})"


async def azure_applens_diagnose(
    command: Annotated[str, "Sub-command: diagnose"],
    resource_id: Annotated[str, "Full ARM resource ID to diagnose"] = "",
    question: Annotated[str, "Description of the problem to diagnose"] = "",
) -> str:
    """Run AppLens diagnostics on an Azure resource to troubleshoot issues. Uses AI-powered conversational diagnostics."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "resource_id": resource_id,
        "question": question,
    }.items() if v}
    try:
        return await _azure_client.call_tool("applens", params)
    except Exception as exc:
        logger.warning("azure_applens_diagnose failed: %s", exc)
        return f"(applens diagnose failed: {exc})"


async def azure_storage_operations(
    command: Annotated[str, "Sub-command: list_accounts, get_account, list_containers, list_blobs, get_blob_properties"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    account_name: Annotated[str, "Storage account name"] = "",
    container_name: Annotated[str, "Blob container name"] = "",
) -> str:
    """Manage and query Azure Storage accounts - list accounts, containers, blobs, and check properties."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "account_name": account_name,
        "container_name": container_name,
    }.items() if v}
    try:
        return await _azure_client.call_tool("storage", params)
    except Exception as exc:
        logger.warning("azure_storage_operations failed: %s", exc)
        return f"(storage operation failed: {exc})"


async def azure_compute_operations(
    command: Annotated[str, "Sub-command: list_vms, get_vm, get_vm_instance_view, list_vmss, restart_vm"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    vm_name: Annotated[str, "Virtual machine name"] = "",
) -> str:
    """Manage and query Azure Virtual Machines - list VMs, get status, instance views, and restart."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "vm_name": vm_name,
    }.items() if v}
    try:
        return await _azure_client.call_tool("compute", params)
    except Exception as exc:
        logger.warning("azure_compute_operations failed: %s", exc)
        return f"(compute operation failed: {exc})"


async def azure_appservice_operations(
    command: Annotated[str, "Sub-command: list_webapps, get_webapp, list_webapp_metrics, restart_webapp"],
    subscription_id: Annotated[str, "Azure subscription ID"] = "",
    resource_group: Annotated[str, "Resource group name"] = "",
    name: Annotated[str, "Web app name"] = "",
) -> str:
    """Manage and query Azure App Service web apps - list apps, get details, check metrics, restart."""
    if _azure_client is None:
        return "(Azure MCP not configured)"
    params = {k: v for k, v in {
        "command": command,
        "subscription_id": subscription_id,
        "resource_group": resource_group,
        "name": name,
    }.items() if v}
    try:
        return await _azure_client.call_tool("appservice", params)
    except Exception as exc:
        logger.warning("azure_appservice_operations failed: %s", exc)
        return f"(appservice operation failed: {exc})"
