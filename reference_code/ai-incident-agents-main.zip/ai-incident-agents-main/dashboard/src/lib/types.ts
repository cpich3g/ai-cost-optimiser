/* ============================================================
 * Types for the AI Incident Responder dashboard
 * ============================================================ */

export type Severity = "critical" | "high" | "medium" | "low";
export type Decision = "approve" | "reject";

export type Stage =
  | "received"
  | "analyzing"
  | "awaiting_approval"
  | "remediating"
  | "resolved"
  | "rejected"
  | "expired";

/* ----- Request / Response shapes ----- */

export interface IncidentReport {
  user_id?: string;
  title: string;
  description: string;
  severity: Severity;
  affected_service: string;
  resource_group?: string;
  resource_name?: string;
}

export interface IncidentReportResponse {
  instance_id: string;
  status: string;
  title: string;
}

export interface DecisionRequest {
  decision: Decision;
  notes?: string;
}

export interface DecisionResponse {
  instance_id: string;
  status: string;
  decision: string;
}

/* ----- Analysis ----- */

export interface RemediationStep {
  step_number: number;
  action: string;
  risk_level: "low" | "medium" | "high";
  estimated_impact: string;
}

export interface AnalysisSummary {
  root_cause: string;
  severity_assessment: string;
  confidence: number;
  num_remediation_steps: number;
  num_azure_findings?: number;
  num_doc_references?: number;
}

export interface DocReference {
  title: string;
  url: string;
}

export interface AnalysisDetail {
  diagnosis: string;
  root_cause: string;
  severity_assessment: string;
  confidence: number;
  azure_findings?: string[];
  doc_references?: DocReference[];
  logs_analyzed: string[];
  metrics_checked: string[];
  remediation_steps: RemediationStep[];
}

/* ----- Orchestration status ----- */

export interface CustomStatus {
  stage: Stage;
  message: string;
  title?: string;
  severity?: string;
  affected_service?: string;
  analysis_summary?: AnalysisSummary;
  analysis_detail?: AnalysisDetail;
  completed_steps?: number;
  total_steps?: number;
}

export interface IncidentStatus {
  instance_id: string;
  runtime_status: string;
  custom_status: CustomStatus | null;
  input: IncidentReport | null;
  output: Record<string, unknown> | null;
  created_time: string | null;
  last_updated_time: string | null;
}

/* ----- Timeline event (for the live flow) ----- */

export interface TimelineEvent {
  id: string;
  timestamp: Date;
  stage: Stage;
  title: string;
  description: string;
  type: "info" | "success" | "warning" | "error" | "action";
}
