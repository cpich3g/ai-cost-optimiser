/* ============================================================
 * API client — talks to the Azure Function App endpoints
 *
 * All calls go through the Next.js rewrite proxy at /fnapi/*
 * which forwards to the real Azure Function App, avoiding CORS.
 * ============================================================ */

import type {
  IncidentReport,
  IncidentReportResponse,
  IncidentStatus,
  DecisionRequest,
  DecisionResponse,
} from "./types";

/** Base path for the Next.js rewrite proxy defined in next.config.ts */
const API_BASE = "/fnapi";
const FUNCTION_KEY = process.env.NEXT_PUBLIC_FUNCTION_KEY ?? "";

function headers(extra?: Record<string, string>): HeadersInit {
  const h: Record<string, string> = {
    "Content-Type": "application/json",
    ...(FUNCTION_KEY ? { "x-functions-key": FUNCTION_KEY } : {}),
    ...extra,
  };
  return h;
}

/** POST /api/incident/report */
export async function reportIncident(
  incident: IncidentReport
): Promise<IncidentReportResponse> {
  const res = await fetch(`${API_BASE}/incident/report`, {
    method: "POST",
    headers: headers({ "x-user-id": incident.user_id ?? "dashboard-user" }),
    body: JSON.stringify(incident),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? `HTTP ${res.status}`);
  }
  return res.json();
}

/** GET /api/incident/{id}/status */
export async function getIncidentStatus(
  instanceId: string
): Promise<IncidentStatus> {
  const res = await fetch(`${API_BASE}/incident/${instanceId}/status`, {
    headers: headers(),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? `HTTP ${res.status}`);
  }
  return res.json();
}

/** POST /api/incident/{id}/decide */
export async function submitDecision(
  instanceId: string,
  decision: DecisionRequest
): Promise<DecisionResponse> {
  const res = await fetch(`${API_BASE}/incident/${instanceId}/decide`, {
    method: "POST",
    headers: headers(),
    body: JSON.stringify(decision),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? `HTTP ${res.status}`);
  }
  return res.json();
}

/** GET /api/incidents */
export async function listIncidents(): Promise<IncidentStatus[]> {
  const res = await fetch(`${API_BASE}/incidents`, {
    headers: headers(),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error ?? `HTTP ${res.status}`);
  }
  return res.json();
}
