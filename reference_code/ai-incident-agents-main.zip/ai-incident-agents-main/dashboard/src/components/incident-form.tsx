"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertCircle, Send, Loader2 } from "lucide-react";
import type { IncidentReport, Severity } from "@/lib/types";

interface Props {
  onSubmit: (incident: IncidentReport) => Promise<void>;
  isSubmitting: boolean;
}

const PRESETS: Record<string, Partial<IncidentReport>> = {
  custom: {},
  "appservice-502": {
    title: "App Service returning 502 Bad Gateway",
    description:
      "Production App Service 'app-contoso-web' is returning HTTP 502 errors for ~40% of requests over the last 20 minutes. Health check endpoint failing. Users reporting blank pages and timeouts on the checkout flow.",
    severity: "critical",
    affected_service: "app-contoso-web",
    resource_group: "rg-durable-agents-hitl",
    resource_name: "app-contoso-web",
  },
  "funcapp-failures": {
    title: "Function App high failure rate",
    description:
      "Azure Function App 'func-order-processor' showing 35% failure rate on the ProcessOrder function. Exceptions in Application Insights indicate timeout errors when connecting to downstream SQL database. Queue messages building up in the poison queue.",
    severity: "high",
    affected_service: "func-order-processor",
    resource_group: "rg-durable-agents-hitl",
    resource_name: "func-order-processor",
  },
  "vm-unresponsive": {
    title: "Production VM unresponsive",
    description:
      "VM 'vm-backend-prod-01' is not responding to RDP or SSH. Heartbeat agent last reported 25 minutes ago. This VM runs the core batch processing service. Dependent nightly jobs are queuing up.",
    severity: "critical",
    affected_service: "vm-backend-prod-01",
    resource_group: "rg-durable-agents-hitl",
    resource_name: "vm-backend-prod-01",
  },
  "storage-throttling": {
    title: "Azure Storage account throttling requests",
    description:
      "Storage account 'stlogsarchive' is returning HTTP 503 (Server Busy) and 429 (Too Many Requests) on blob operations. Ingestion pipeline is failing to write telemetry data. Approximately 15,000 operations/sec hitting the account.",
    severity: "high",
    affected_service: "stlogsarchive",
    resource_group: "rg-durable-agents-hitl",
    resource_name: "stlogsarchive",
  },
  "sql-dtu-exhaustion": {
    title: "Azure SQL DTU exhaustion causing query timeouts",
    description:
      "Azure SQL Database 'sqldb-inventory' on server 'sql-contoso-prod' reporting DTU consumption at 98-100% for the past 30 minutes. Application tier seeing CommandTimeout exceptions. Slow queries identified in Query Performance Insight.",
    severity: "high",
    affected_service: "sqldb-inventory",
    resource_group: "rg-durable-agents-hitl",
    resource_name: "sql-contoso-prod",
  },
};

export default function IncidentForm({ onSubmit, isSubmitting }: Props) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState<Severity>("critical");
  const [affected, setAffected] = useState("");
  const [resourceGroup, setResourceGroup] = useState("");
  const [resourceName, setResourceName] = useState("");
  const [preset, setPreset] = useState("custom");

  function applyPreset(key: string) {
    setPreset(key);
    if (key === "custom") return;
    const p = PRESETS[key];
    if (p.title) setTitle(p.title);
    if (p.description) setDescription(p.description);
    if (p.severity) setSeverity(p.severity);
    if (p.affected_service) setAffected(p.affected_service);
    setResourceGroup(p.resource_group ?? "");
    setResourceName(p.resource_name ?? "");
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    await onSubmit({
      title,
      description,
      severity,
      affected_service: affected,
      resource_group: resourceGroup || undefined,
      resource_name: resourceName || undefined,
      user_id: "dashboard-user",
    });
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <AlertCircle className="h-4 w-4 text-destructive" />
          Report Incident
        </CardTitle>
        <CardDescription>
          Submit a new incident for AI analysis and remediation.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-3">
          {/* Preset picker */}
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">
              Quick Fill
            </label>
            <Select value={preset} onValueChange={applyPreset}>
              <SelectTrigger className="h-8 text-xs">
                <SelectValue placeholder="Choose a preset…" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="custom">Custom</SelectItem>
                <SelectItem value="appservice-502">
                  App Service 502 Bad Gateway
                </SelectItem>
                <SelectItem value="funcapp-failures">
                  Function App High Failure Rate
                </SelectItem>
                <SelectItem value="vm-unresponsive">
                  Production VM Unresponsive
                </SelectItem>
                <SelectItem value="storage-throttling">
                  Storage Account Throttling
                </SelectItem>
                <SelectItem value="sql-dtu-exhaustion">
                  SQL DTU Exhaustion
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Title */}
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">
              Title
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Brief incident title"
              required
              className="h-8 text-sm"
            />
          </div>

          {/* Description */}
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">
              Description
            </label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the incident: symptoms, impact, timeline…"
              required
              className="min-h-[80px] text-sm"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
            {/* Severity */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">
                Severity
              </label>
              <Select
                value={severity}
                onValueChange={(v) => setSeverity(v as Severity)}
              >
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-red-500" />
                      Critical
                    </span>
                  </SelectItem>
                  <SelectItem value="high">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-orange-500" />
                      High
                    </span>
                  </SelectItem>
                  <SelectItem value="medium">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-yellow-500" />
                      Medium
                    </span>
                  </SelectItem>
                  <SelectItem value="low">
                    <span className="flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-green-500" />
                      Low
                    </span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Affected service */}
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">
                Affected Service
              </label>
              <Input
                value={affected}
                onChange={(e) => setAffected(e.target.value)}
                placeholder="e.g. payment-api"
                className="h-8 text-sm"
              />
            </div>
          </div>

          {/* Azure resource identifiers (optional) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">
                Resource Group
              </label>
              <Input
                value={resourceGroup}
                onChange={(e) => setResourceGroup(e.target.value)}
                placeholder="e.g. rg-production"
                className="h-8 text-sm font-mono"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">
                Resource Name
              </label>
              <Input
                value={resourceName}
                onChange={(e) => setResourceName(e.target.value)}
                placeholder="e.g. app-contoso-web"
                className="h-8 text-sm font-mono"
              />
            </div>
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={isSubmitting || !title || !description}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Submitting…
              </>
            ) : (
              <>
                <Send className="h-4 w-4" />
                Submit Incident
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
