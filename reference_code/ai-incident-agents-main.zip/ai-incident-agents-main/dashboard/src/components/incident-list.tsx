"use client";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import type { IncidentStatus } from "@/lib/types";
import {
  AlertCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  List,
} from "lucide-react";

interface Props {
  incidents: IncidentStatus[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  isLoading: boolean;
}

function statusIcon(runtime: string, stage?: string) {
  if (stage === "rejected")
    return <XCircle className="h-3.5 w-3.5 text-red-500" />;
  if (stage === "expired")
    return <Clock className="h-3.5 w-3.5 text-yellow-600" />;
  if (runtime === "Completed" || stage === "resolved")
    return <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />;
  if (runtime === "Running")
    return <Loader2 className="h-3.5 w-3.5 text-blue-500 animate-spin" />;
  return <AlertCircle className="h-3.5 w-3.5 text-muted-foreground" />;
}

function stageBadge(stage?: string, runtimeStatus?: string) {
  const colors: Record<string, string> = {
    received: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    analyzing: "bg-purple-500/10 text-purple-600 border-purple-500/20",
    awaiting_approval: "bg-amber-500/10 text-amber-600 border-amber-500/20",
    remediating: "bg-indigo-500/10 text-indigo-600 border-indigo-500/20",
    resolved: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
    rejected: "bg-red-500/10 text-red-600 border-red-500/20",
    expired: "bg-yellow-500/10 text-yellow-700 border-yellow-500/20",
    completed: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
    running: "bg-blue-500/10 text-blue-600 border-blue-500/20",
    pending: "bg-zinc-500/10 text-zinc-600 border-zinc-500/20",
  };
  const label = stage ?? runtimeStatus?.toLowerCase() ?? "pending";
  return (
    <Badge
      variant="outline"
      className={cn("text-[9px]", colors[label] ?? "")}
    >
      {label.replace(/_/g, " ")}
    </Badge>
  );
}

export default function IncidentList({
  incidents,
  selectedId,
  onSelect,
  isLoading,
}: Props) {
  return (
    <Card className="flex flex-col h-full min-h-0">
      <CardHeader className="pb-2 shrink-0">
        <CardTitle className="flex items-center gap-2 text-base">
          <List className="h-4 w-4" />
          Incidents
          {incidents.length > 0 && (
            <Badge variant="secondary" className="text-[10px]">
              {incidents.length}
            </Badge>
          )}
          {isLoading && (
            <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground ml-auto" />
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 px-2 pb-2 overflow-hidden">
        <ScrollArea className="h-full">
          {incidents.length === 0 && !isLoading && (
            <p className="text-xs text-muted-foreground text-center py-8">
              No incidents yet. Submit one above.
            </p>
          )}
          <div className="space-y-1">
            {incidents.map((inc) => {
              const cs = inc.custom_status;
              const isSelected = inc.instance_id === selectedId;
              return (
                <button
                  key={inc.instance_id}
                  onClick={() => onSelect(inc.instance_id)}
                  className={cn(
                    "w-full text-left rounded-md p-2.5 transition-colors",
                    "hover:bg-accent/50",
                    isSelected && "bg-accent border border-border"
                  )}
                >
                  <div className="flex items-start gap-2">
                    {statusIcon(inc.runtime_status, cs?.stage)}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">
                        {cs?.title ?? inc.input?.title ?? inc.instance_id.slice(0, 8)}
                      </p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        {stageBadge(cs?.stage, inc.runtime_status)}
                        {inc.created_time && (
                          <span className="text-[9px] text-muted-foreground">
                            {new Date(inc.created_time).toLocaleTimeString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
