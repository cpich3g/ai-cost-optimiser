"use client";

import { Badge } from "@/components/ui/badge";
import type { Stage } from "@/lib/types";
import { cn } from "@/lib/utils";
import {
  Inbox,
  BrainCircuit,
  Clock,
  Wrench,
  CheckCircle2,
  XCircle,
  Timer,
} from "lucide-react";

/** Ordered pipeline stages. */
const STAGES: {
  key: Stage;
  label: string;
  icon: React.ElementType;
}[] = [
  { key: "received", label: "Received", icon: Inbox },
  { key: "analyzing", label: "AI Analyzing", icon: BrainCircuit },
  { key: "awaiting_approval", label: "Awaiting Approval", icon: Clock },
  { key: "remediating", label: "Remediating", icon: Wrench },
  { key: "resolved", label: "Resolved", icon: CheckCircle2 },
];

const TERMINAL_STAGES: Record<
  string,
  { label: string; icon: React.ElementType; color: string }
> = {
  rejected: { label: "Rejected", icon: XCircle, color: "text-red-500" },
  expired: { label: "Expired", icon: Timer, color: "text-yellow-600" },
};

function stageIndex(stage: Stage | undefined): number {
  if (!stage) return -1;
  return STAGES.findIndex((s) => s.key === stage);
}

interface Props {
  currentStage: Stage | undefined;
  completedSteps?: number;
  totalSteps?: number;
}

export default function FlowTimeline({
  currentStage,
  completedSteps,
  totalSteps,
}: Props) {
  const currentIdx = stageIndex(currentStage);
  const isTerminal =
    currentStage && currentStage in TERMINAL_STAGES;

  return (
    <div className="space-y-1">
      {/* Linear pipeline */}
      <div className="flex items-center justify-center gap-0 min-w-fit">
        {STAGES.map((stage, idx) => {
          const Icon = stage.icon;
          const isActive = currentStage === stage.key;
          const isCompleted = !isTerminal && currentIdx > idx;
          const isFuture = !isTerminal && currentIdx < idx;

          return (
            <div key={stage.key} className="flex items-center">
              {/* Node */}
              <div className="flex flex-col items-center">
                <div
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-full border-2 transition-all duration-500",
                    isActive &&
                      "border-primary bg-primary text-primary-foreground shadow-md shadow-primary/25 animate-pulse",
                    isCompleted &&
                      "border-emerald-500 bg-emerald-500 text-white",
                    isFuture &&
                      "border-muted-foreground/25 bg-muted text-muted-foreground/50",
                    isTerminal &&
                      !isActive &&
                      !isCompleted &&
                      "border-muted-foreground/25 bg-muted text-muted-foreground/50"
                  )}
                >
                  <Icon className="h-4 w-4" />
                </div>
                <span
                  className={cn(
                    "mt-1 text-[10px] font-medium leading-tight text-center w-16",
                    isActive && "text-primary font-semibold",
                    isCompleted && "text-emerald-600",
                    isFuture && "text-muted-foreground/50"
                  )}
                >
                  {stage.label}
                </span>
                {/* Progress under remediating */}
                {stage.key === "remediating" &&
                  isActive &&
                  totalSteps != null &&
                  totalSteps > 0 && (
                    <span className="text-[9px] text-muted-foreground">
                      {completedSteps ?? 0}/{totalSteps}
                    </span>
                  )}
              </div>

              {/* Connector */}
              {idx < STAGES.length - 1 && (
                <div
                  className={cn(
                    "h-0.5 w-6 mx-0.5 transition-colors duration-500",
                    currentIdx > idx ? "bg-emerald-500" : "bg-muted-foreground/20"
                  )}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* Terminal badge (rejected / expired) */}
      {isTerminal && currentStage && (
        <div className="flex justify-center pt-1">
          <Badge
            variant="destructive"
            className="gap-1 animate-in fade-in slide-in-from-bottom-2"
          >
            {(() => {
              const t = TERMINAL_STAGES[currentStage];
              const TIcon = t.icon;
              return (
                <>
                  <TIcon className="h-3 w-3" />
                  {t.label}
                </>
              );
            })()}
          </Badge>
        </div>
      )}
    </div>
  );
}
