"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  CheckCircle2,
  XCircle,
  Loader2,
  ShieldAlert,
  Brain,
  Target,
  BarChart3,
  Wrench,
  AlertTriangle,
  Globe,
  FileText,
} from "lucide-react";
import type { IncidentStatus, Decision, RemediationStep, DocReference } from "@/lib/types";
import { cn } from "@/lib/utils";

interface Props {
  incident: IncidentStatus;
  onDecide: (decision: Decision, notes: string) => Promise<void>;
  isDeciding: boolean;
}

function SeverityBadge({ severity }: { severity: string | undefined }) {
  const colors: Record<string, string> = {
    critical: "bg-red-500/10 text-red-600 border-red-500/20",
    high: "bg-orange-500/10 text-orange-600 border-orange-500/20",
    medium: "bg-yellow-500/10 text-yellow-700 border-yellow-500/20",
    low: "bg-green-500/10 text-green-600 border-green-500/20",
  };
  return (
    <Badge
      variant="outline"
      className={cn("text-[10px] uppercase", colors[severity ?? ""] ?? "")}
    >
      {severity ?? "unknown"}
    </Badge>
  );
}

function ConfidenceBar({ value }: { value: number }) {
  const color =
    value >= 80
      ? "bg-emerald-500"
      : value >= 60
        ? "bg-yellow-500"
        : "bg-red-500";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all duration-700", color)}
          style={{ width: `${value}%` }}
        />
      </div>
      <span className="text-xs font-semibold tabular-nums">{value}%</span>
    </div>
  );
}

export default function ApprovalPanel({
  incident,
  onDecide,
  isDeciding,
}: Props) {
  const [notes, setNotes] = useState("");
  const cs = incident.custom_status;
  const summary = cs?.analysis_summary;
  const detail = cs?.analysis_detail;
  const stage = cs?.stage;
  const isAwaitingApproval = stage === "awaiting_approval";

  return (
    <Card className="h-full flex flex-col min-h-0 overflow-hidden">
      <CardHeader className="pb-3 shrink-0">
        <CardTitle className="flex items-center gap-2 text-base">
          <ShieldAlert className="h-4 w-4 text-amber-500" />
          Incident Details
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 overflow-y-auto px-3 sm:px-6 pb-4 space-y-4">
        {/* Title + severity */}
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold text-sm">
              {cs?.title ?? incident.input?.title ?? "Untitled Incident"}
            </h3>
            <SeverityBadge severity={cs?.severity ?? incident.input?.severity} />
          </div>
          {cs?.affected_service && (
            <p className="text-xs text-muted-foreground mt-0.5">
              Service: <span className="font-mono">{cs.affected_service}</span>
            </p>
          )}
        </div>

        {/* Current status message */}
        <div className="rounded-md border bg-muted/50 p-3">
          <p className="text-sm">
            {cs?.message ?? "Waiting for status…"}
          </p>
          <div className="flex items-center gap-2 mt-1.5">
            <Badge variant="secondary" className="text-[10px]">
              {incident.runtime_status}
            </Badge>
            {incident.last_updated_time && (
              <span className="text-[10px] text-muted-foreground">
                Updated: {new Date(incident.last_updated_time).toLocaleTimeString()}
              </span>
            )}
          </div>
        </div>

        {/* Analysis summary */}
        {summary && (
          <>
            <Separator />
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                <Brain className="h-3.5 w-3.5" />
                AI Analysis
              </h4>

              {/* Diagnosis */}
              {detail?.diagnosis && (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Brain className="h-3 w-3" />
                    Diagnosis
                  </div>
                  <p className="text-sm bg-muted/50 rounded-md p-2 leading-relaxed">
                    {detail.diagnosis}
                  </p>
                </div>
              )}

              {/* Root Cause */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  <Target className="h-3 w-3" />
                  Root Cause
                </div>
                <p className="text-sm bg-muted/50 rounded-md p-2 leading-relaxed">
                  {summary.root_cause || "—"}
                </p>
              </div>

              {/* Confidence */}
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                  <BarChart3 className="h-3 w-3" />
                  Confidence
                </div>
                <ConfidenceBar value={summary.confidence} />
              </div>

              {/* Severity assessment */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">
                  AI Severity Assessment:
                </span>
                <SeverityBadge severity={summary.severity_assessment} />
              </div>

              {/* Remediation Plan */}
              {detail?.remediation_steps && detail.remediation_steps.length > 0 ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Wrench className="h-3 w-3" />
                    Remediation Plan ({detail.remediation_steps.length} step
                    {detail.remediation_steps.length !== 1 ? "s" : ""})
                  </div>
                  <div className="space-y-1.5">
                    {detail.remediation_steps.map((step: RemediationStep, idx: number) => (
                      <div
                        key={step.step_number ?? idx}
                        className="rounded-md border bg-muted/30 p-2 text-xs"
                      >
                        <div className="flex items-center gap-2 justify-between">
                          <span className="font-semibold">
                            Step {step.step_number ?? idx + 1}
                          </span>
                          <Badge
                            variant="outline"
                            className={cn(
                              "text-[9px]",
                              step.risk_level === "high"
                                ? "border-red-500/30 text-red-600"
                                : step.risk_level === "medium"
                                  ? "border-yellow-500/30 text-yellow-700"
                                  : "border-green-500/30 text-green-600"
                            )}
                          >
                            {step.risk_level} risk
                          </Badge>
                        </div>
                        <p className="mt-1 text-muted-foreground leading-relaxed">
                          {step.action}
                        </p>
                        {step.estimated_impact && (
                          <p className="mt-0.5 text-[10px] text-muted-foreground/70 italic">
                            Impact: {step.estimated_impact}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Wrench className="h-3 w-3" />
                  {summary.num_remediation_steps} remediation step
                  {summary.num_remediation_steps !== 1 ? "s" : ""} proposed
                </div>
              )}

              {/* Azure Findings (from MCP) */}
              {detail?.azure_findings && detail.azure_findings.length > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Globe className="h-3 w-3" />
                    Azure Findings ({detail.azure_findings.length})
                  </div>
                  <ul className="space-y-1">
                    {detail.azure_findings.map((finding: string, idx: number) => (
                      <li
                        key={idx}
                        className="text-[11px] text-muted-foreground bg-muted/50 rounded-md p-2"
                      >
                        {finding}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : summary.num_azure_findings != null && summary.num_azure_findings > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <Globe className="h-3 w-3" />
                    Azure Findings ({summary.num_azure_findings})
                  </div>
                  <p className="text-[11px] text-muted-foreground bg-muted/50 rounded-md p-2">
                    Live diagnostics gathered via Azure MCP Server
                  </p>
                </div>
              ) : null}

              {/* Doc References (from Learn MCP) */}
              {detail?.doc_references && detail.doc_references.length > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <FileText className="h-3 w-3" />
                    Documentation ({detail.doc_references.length} article
                    {detail.doc_references.length !== 1 ? "s" : ""})
                  </div>
                  <ul className="space-y-1">
                    {detail.doc_references.map((ref: DocReference, idx: number) => (
                      <li key={idx} className="text-[11px] bg-muted/50 rounded-md p-2">
                        <a
                          href={ref.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-primary hover:underline"
                        >
                          {ref.title}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : summary.num_doc_references != null && summary.num_doc_references > 0 ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
                    <FileText className="h-3 w-3" />
                    Documentation ({summary.num_doc_references} articles)
                  </div>
                  <p className="text-[11px] text-muted-foreground bg-muted/50 rounded-md p-2">
                    Relevant Microsoft Learn articles sourced via MCP
                  </p>
                </div>
              ) : null}
            </div>
          </>
        )}

        {/* Remediating progress */}
        {stage === "remediating" &&
          cs?.total_steps != null &&
          cs.total_steps > 0 && (
            <>
              <Separator />
              <div className="space-y-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <Wrench className="h-3.5 w-3.5 animate-spin" />
                  Remediation Progress
                </h4>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-3 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full bg-primary transition-all duration-500"
                      style={{
                        width: `${((cs.completed_steps ?? 0) / cs.total_steps) * 100}%`,
                      }}
                    />
                  </div>
                  <span className="text-xs font-mono tabular-nums">
                    {cs.completed_steps ?? 0}/{cs.total_steps}
                  </span>
                </div>
              </div>
            </>
          )}

        {/* Resolved / Rejected output */}
        {incident.output && (stage === "resolved" || stage === "rejected") && (
          <>
            <Separator />
            <div className="rounded-md border p-3 bg-muted/30">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                Outcome
              </h4>
              <pre className="text-xs font-mono whitespace-pre-wrap break-words">
                {JSON.stringify(incident.output, null, 2)}
              </pre>
            </div>
          </>
        )}

      </CardContent>

      {/* Approve / Reject — pinned at bottom, always visible */}
      {isAwaitingApproval && (
        <div className="shrink-0 border-t px-3 sm:px-6 py-3 space-y-3 bg-card">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
            Human Decision Required
          </div>

          <Textarea
            placeholder="Operator notes (optional)…"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="min-h-[48px] max-h-[80px] text-sm"
          />

          <div className="flex gap-2">
            <Button
              variant="default"
              className="flex-1 bg-emerald-600 hover:bg-emerald-700"
              disabled={isDeciding}
              onClick={() => onDecide("approve", notes)}
            >
              {isDeciding ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <CheckCircle2 className="h-4 w-4" />
              )}
              Approve
            </Button>
            <Button
              variant="destructive"
              className="flex-1"
              disabled={isDeciding}
              onClick={() => onDecide("reject", notes)}
            >
              {isDeciding ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <XCircle className="h-4 w-4" />
              )}
              Reject
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
