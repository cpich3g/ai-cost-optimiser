"use client";

import { useRef, useEffect } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import {
  Activity,
  Inbox,
  BrainCircuit,
  Clock,
  Wrench,
  CheckCircle2,
  XCircle,
  Timer,
  Info,
  AlertTriangle,
} from "lucide-react";
import type { TimelineEvent } from "@/lib/types";

interface Props {
  events: TimelineEvent[];
}

function eventIcon(type: TimelineEvent["type"]) {
  const map: Record<string, React.ElementType> = {
    info: Info,
    success: CheckCircle2,
    warning: AlertTriangle,
    error: XCircle,
    action: Wrench,
  };
  return map[type] ?? Info;
}

function stageIcon(stage: string) {
  const map: Record<string, React.ElementType> = {
    received: Inbox,
    analyzing: BrainCircuit,
    awaiting_approval: Clock,
    remediating: Wrench,
    resolved: CheckCircle2,
    rejected: XCircle,
    expired: Timer,
  };
  return map[stage] ?? Info;
}

const typeColors: Record<string, string> = {
  info: "border-blue-500/30 bg-blue-500/5",
  success: "border-emerald-500/30 bg-emerald-500/5",
  warning: "border-amber-500/30 bg-amber-500/5",
  error: "border-red-500/30 bg-red-500/5",
  action: "border-indigo-500/30 bg-indigo-500/5",
};

const dotColors: Record<string, string> = {
  info: "bg-blue-500",
  success: "bg-emerald-500",
  warning: "bg-amber-500",
  error: "bg-red-500",
  action: "bg-indigo-500",
};

export default function EventLog({ events }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [events.length]);

  return (
    <Card className="flex flex-col h-full min-h-0">
      <CardHeader className="pb-2 shrink-0">
        <CardTitle className="flex items-center gap-2 text-base">
          <Activity className="h-4 w-4" />
          Live Activity
          {events.length > 0 && (
            <Badge variant="secondary" className="text-[10px]">
              {events.length}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 min-h-0 px-3 pb-3 overflow-hidden">
        <ScrollArea className="h-full">
          {events.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
              <Activity className="h-8 w-8 mb-2 opacity-30" />
              <p className="text-xs">Events will appear here as the orchestration runs.</p>
            </div>
          ) : (
            <div className="relative pl-4">
              {/* Vertical line */}
              <div className="absolute left-[7px] top-2 bottom-2 w-px bg-border" />

              <div className="space-y-3">
                {events.map((ev) => {
                  const StageIcon = stageIcon(ev.stage);
                  return (
                    <div
                      key={ev.id}
                      className={cn(
                        "relative pl-5 animate-in fade-in slide-in-from-left-2 duration-300"
                      )}
                    >
                      {/* Dot on the line */}
                      <div
                        className={cn(
                          "absolute left-0 top-2 h-[9px] w-[9px] rounded-full ring-2 ring-background",
                          dotColors[ev.type]
                        )}
                      />

                      <div
                        className={cn(
                          "rounded-md border p-2.5",
                          typeColors[ev.type]
                        )}
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          <StageIcon className="h-3 w-3 shrink-0 text-muted-foreground" />
                          <span className="text-xs font-semibold truncate">
                            {ev.title}
                          </span>
                          <span className="ml-auto shrink-0 text-[9px] text-muted-foreground tabular-nums">
                            {ev.timestamp.toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed break-words">
                          {ev.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div ref={bottomRef} />
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
