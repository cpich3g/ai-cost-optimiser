"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import type {
  IncidentStatus,
  TimelineEvent,
  Stage,
  Decision,
} from "@/lib/types";
import {
  reportIncident as apiReport,
  getIncidentStatus,
  submitDecision,
  listIncidents,
} from "@/lib/api";

/**
 * Central state hook for the incident dashboard.
 *
 * Handles:
 *  - Incident list (polled)
 *  - Selected incident status (polled faster while Running)
 *  - Timeline events derived from status changes
 *  - Form submission / decision submission
 */
export function useIncidentDashboard() {
  /* ---- Incident list ---- */
  const [incidents, setIncidents] = useState<IncidentStatus[]>([]);
  const [listLoading, setListLoading] = useState(false);

  /* ---- Selected incident ---- */
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedIncident, setSelectedIncident] =
    useState<IncidentStatus | null>(null);

  /* ---- Timeline events for selected incident ---- */
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const prevStageRef = useRef<string | null>(null);
  const prevCompletedStepsRef = useRef<number>(0);

  /* ---- UI flags ---- */
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDeciding, setIsDeciding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // ------------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------------

  function addEvent(
    stage: Stage,
    title: string,
    description: string,
    type: TimelineEvent["type"] = "info"
  ) {
    setEvents((prev) => [
      ...prev,
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date(),
        stage,
        title,
        description,
        type,
      },
    ]);
  }

  // ------------------------------------------------------------------
  // Fetch incident list
  // ------------------------------------------------------------------
  const fetchList = useCallback(async () => {
    try {
      setListLoading(true);
      const list = await listIncidents();
      setIncidents(list);
    } catch (e: unknown) {
      console.error("Failed to list incidents:", e);
    } finally {
      setListLoading(false);
    }
  }, []);

  // Poll list every 10s
  useEffect(() => {
    fetchList();
    const interval = setInterval(fetchList, 10000);
    return () => clearInterval(interval);
  }, [fetchList]);

  // ------------------------------------------------------------------
  // Poll selected incident status
  // ------------------------------------------------------------------
  const fetchStatus = useCallback(async () => {
    if (!selectedId) return;
    try {
      const status = await getIncidentStatus(selectedId);
      setSelectedIncident(status);

      // Derive timeline events from stage changes
      const stage = status.custom_status?.stage;
      if (stage && stage !== prevStageRef.current) {
        const prevStage = prevStageRef.current;
        prevStageRef.current = stage;

        // Map stage transitions to events
        switch (stage) {
          case "received":
            addEvent(
              "received",
              "Incident Received",
              status.custom_status?.message ?? "Incident report received.",
              "info"
            );
            break;
          case "analyzing":
            addEvent(
              "analyzing",
              "AI Analysis Started",
              "The AI agent is examining logs, metrics, and recent changes.",
              "info"
            );
            break;
          case "awaiting_approval":
            addEvent(
              "awaiting_approval",
              "Analysis Complete",
              `Root cause identified with ${status.custom_status?.analysis_summary?.confidence ?? "?"}% confidence. ` +
                `${status.custom_status?.analysis_summary?.num_remediation_steps ?? 0} remediation steps proposed.`,
              "warning"
            );
            addEvent(
              "awaiting_approval",
              "Human Approval Required",
              "Review the analysis and approve or reject the remediation plan.",
              "action"
            );
            break;
          case "remediating":
            if (prevStage === "awaiting_approval") {
              addEvent(
                "remediating",
                "Remediation Approved",
                "The remediation plan has been approved. Executing steps…",
                "success"
              );
            }
            break;
          case "resolved":
            addEvent(
              "resolved",
              "Incident Resolved",
              "All remediation steps have been executed successfully.",
              "success"
            );
            break;
          case "rejected":
            addEvent(
              "rejected",
              "Remediation Rejected",
              status.custom_status?.message ?? "The remediation plan was rejected.",
              "error"
            );
            break;
          case "expired":
            addEvent(
              "expired",
              "Approval Expired",
              "No response received within the timeout window.",
              "error"
            );
            break;
        }
      }

      // Track remediation step progress
      if (
        stage === "remediating" &&
        status.custom_status?.completed_steps != null
      ) {
        const completed = status.custom_status.completed_steps;
        const total = status.custom_status.total_steps ?? 0;
        // Add events only for newly completed steps since last poll
        while (prevCompletedStepsRef.current < completed) {
          prevCompletedStepsRef.current += 1;
          const stepNum = prevCompletedStepsRef.current;
          addEvent(
            "remediating",
            `Step ${stepNum}/${total} Completed`,
            `Remediation step ${stepNum} finished.`,
            "info"
          );
        }
      }
    } catch (e: unknown) {
      console.error("Failed to get status:", e);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedId]);

  // Poll: 2s while Running, 5s otherwise
  useEffect(() => {
    if (!selectedId) return;
    // Fetch immediately
    fetchStatus();
    const interval = setInterval(() => {
      fetchStatus();
    }, selectedIncident?.runtime_status === "Running" ? 2000 : 5000);
    return () => clearInterval(interval);
  }, [selectedId, fetchStatus, selectedIncident?.runtime_status]);

  // Reset events when selecting a different incident
  useEffect(() => {
    prevStageRef.current = null;
    prevCompletedStepsRef.current = 0;
    setEvents([]);
    setSelectedIncident(null);
  }, [selectedId]);

  // ------------------------------------------------------------------
  // Actions
  // ------------------------------------------------------------------

  async function submitIncident(
    incident: Parameters<typeof apiReport>[0]
  ) {
    setError(null);
    setIsSubmitting(true);
    try {
      const result = await apiReport(incident);
      setSelectedId(result.instance_id);
      // Immediately refresh list
      await fetchList();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setError(msg);
    } finally {
      setIsSubmitting(false);
    }
  }

  async function decide(decision: Decision, notes: string) {
    if (!selectedId) return;
    setIsDeciding(true);
    setError(null);
    try {
      await submitDecision(selectedId, { decision, notes });
      addEvent(
        decision === "approve" ? "remediating" : "rejected",
        decision === "approve" ? "Decision: Approved" : "Decision: Rejected",
        notes ? `Operator notes: ${notes}` : "No additional notes.",
        decision === "approve" ? "success" : "error"
      );
      // Quick refresh
      await fetchStatus();
      await fetchList();
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      setError(msg);
    } finally {
      setIsDeciding(false);
    }
  }

  return {
    // List
    incidents,
    listLoading,
    fetchList,
    // Selection
    selectedId,
    setSelectedId,
    selectedIncident,
    // Events
    events,
    // Actions
    submitIncident,
    isSubmitting,
    decide,
    isDeciding,
    // Error
    error,
    setError,
  };
}
