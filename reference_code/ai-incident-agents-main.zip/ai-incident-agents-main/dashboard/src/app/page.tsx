"use client";

import IncidentForm from "@/components/incident-form";
import IncidentList from "@/components/incident-list";
import FlowTimeline from "@/components/flow-timeline";
import ApprovalPanel from "@/components/approval-panel";
import EventLog from "@/components/event-log";
import { useIncidentDashboard } from "@/hooks/use-incident-dashboard";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  ShieldCheck,
  Zap,
  XCircle,
  Bot,
} from "lucide-react";

export default function DashboardPage() {
  const {
    incidents,
    listLoading,
    selectedId,
    setSelectedId,
    selectedIncident,
    events,
    submitIncident,
    isSubmitting,
    decide,
    isDeciding,
    error,
    setError,
  } = useIncidentDashboard();

  return (
    <div className="min-h-screen bg-background">
      {/* ---- Header ---- */}
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="mx-auto flex h-14 max-w-7xl items-center gap-4 px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div>
              <h1 className="text-sm font-bold leading-none">
                AI Incident Responder
              </h1>
              <p className="text-[10px] text-muted-foreground">
                Durable Agents &middot; Human-in-the-Loop
              </p>
            </div>
          </div>

          <div className="ml-auto hidden sm:flex items-center gap-3">
            <Badge variant="outline" className="gap-1 text-[10px]">
              <Bot className="h-3 w-3" />
              2 Agents
            </Badge>
            <Badge variant="outline" className="gap-1 text-[10px]">
              <Zap className="h-3 w-3" />
              Polling
            </Badge>
          </div>
        </div>
      </header>

      {/* ---- Error banner ---- */}
      {error && (
        <div className="mx-auto max-w-7xl px-4 pt-3">
          <Alert variant="destructive">
            <XCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              {error}
              <button
                onClick={() => setError(null)}
                className="text-xs underline ml-4"
              >
                Dismiss
              </button>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* ---- Main grid ---- */}
      <main className="mx-auto max-w-7xl px-2 sm:px-4 py-3 sm:py-4 lg:h-[calc(100vh-3.5rem)] flex flex-col lg:overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 lg:gap-4 flex-1 min-h-0">
          {/* ====== LEFT COLUMN: Form + List ====== */}
          <div className="lg:col-span-4 flex flex-col gap-3 lg:gap-4 min-h-0">
            <div className="shrink-0">
              <IncidentForm
                onSubmit={submitIncident}
                isSubmitting={isSubmitting}
              />
            </div>
            <div className="h-[300px] lg:h-0 lg:flex-1 min-h-0 overflow-hidden">
              <IncidentList
                incidents={incidents}
                selectedId={selectedId}
                onSelect={setSelectedId}
                isLoading={listLoading}
              />
            </div>
          </div>

          {/* ====== RIGHT COLUMN: Flow + Details + Events ====== */}
          <div className="lg:col-span-8 flex flex-col gap-3 lg:gap-4 min-h-0">
            {!selectedId ? (
              <div className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed text-muted-foreground min-h-[200px]">
                <ShieldCheck className="h-12 w-12 mb-3 opacity-20" />
                <p className="text-sm font-medium">No incident selected</p>
                <p className="text-xs">
                  Submit a new incident or select one from the list.
                </p>
              </div>
            ) : (
              <>
                {/* Flow timeline */}
                {selectedIncident && (
                  <div className="shrink-0 rounded-lg border bg-card p-3 sm:p-4 overflow-x-auto">
                    <FlowTimeline
                      currentStage={selectedIncident.custom_status?.stage}
                      completedSteps={
                        selectedIncident.custom_status?.completed_steps
                      }
                      totalSteps={selectedIncident.custom_status?.total_steps}
                    />
                  </div>
                )}

                {/* Side-by-side: Approval panel + Event log */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 lg:gap-4 flex-1 min-h-0">
                  {/* Approval / Details */}
                  <div className="h-[500px] lg:h-full overflow-hidden">
                    {selectedIncident ? (
                      <ApprovalPanel
                        incident={selectedIncident}
                        onDecide={decide}
                        isDeciding={isDeciding}
                      />
                    ) : (
                      <div className="rounded-lg border flex items-center justify-center text-muted-foreground text-xs h-full">
                        Loading incident details...
                      </div>
                    )}
                  </div>

                  {/* Event log */}
                  <div className="h-[400px] lg:h-full overflow-hidden">
                    <EventLog events={events} />
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
