import type { NextConfig } from "next";

const API_URL =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:7071/api";

const FUNCTION_KEY = process.env.NEXT_PUBLIC_FUNCTION_KEY ?? "";

const nextConfig: NextConfig = {
  /** Proxy /fnapi/* to the Azure Function App to avoid CORS issues. */
  async rewrites() {
    const qs = FUNCTION_KEY ? `?code=${FUNCTION_KEY}` : "";
    return [
      {
        source: "/fnapi/:path*",
        destination: `${API_URL}/:path*${qs}`,
      },
    ];
  },
};

export default nextConfig;
