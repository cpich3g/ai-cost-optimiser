"""Central configuration for the AI Incident Responder sample.

All configurable constants and environment variable lookups live here.
Override via environment variables or local.settings.json.
"""

import os

# =============================================================================
# Azure OpenAI (read automatically by AzureOpenAIChatClient via env vars)
#   AZURE_OPENAI_ENDPOINT
#   AZURE_OPENAI_CHAT_DEPLOYMENT_NAME
#   AZURE_OPENAI_API_KEY
# =============================================================================

# =============================================================================
# SignalR
# =============================================================================
SIGNALR_HUB_NAME = "incidenthub"
SIGNALR_CONNECTION_SETTING = "AzureSignalRConnectionString"

# =============================================================================
# Orchestration tunables
# =============================================================================
APPROVAL_TIMEOUT_HOURS = int(os.getenv("APPROVAL_TIMEOUT_HOURS", "72"))

# =============================================================================
# MCP (Model Context Protocol) Server URLs
# =============================================================================
# Microsoft Learn MCP -- public endpoint, no auth required
LEARN_MCP_URL = os.getenv(
    "LEARN_MCP_URL", "https://learn.microsoft.com/api/mcp"
)

# Azure MCP Server -- hosted on Container App with Managed Identity
# Set this to your Container App URL after deploying infra/azure-mcp-server.bicep
AZURE_MCP_SERVER_URL = os.getenv("AZURE_MCP_SERVER_URL", "")

# Azure MCP Server -- Entra ID app registration client ID for auth
# When set, the Function App uses its Managed Identity to acquire a Bearer token
# scoped to api://<APP_ID>/.default before calling the MCP server.
AZURE_MCP_APP_ID = os.getenv("AZURE_MCP_APP_ID", "")

# Master switch to enable/disable MCP tools. When "false", the analyzer agent
# runs purely on its AI knowledge without reaching out to MCP servers.
# This is useful when MCP servers are unreliable or for quick demos.
ENABLE_MCP_TOOLS = os.getenv("ENABLE_MCP_TOOLS", "true").lower() in ("true", "1", "yes")
